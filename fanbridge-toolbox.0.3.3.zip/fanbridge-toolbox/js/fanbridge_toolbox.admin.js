/**
 * Fanbridge namespace.
 */
if (typeof(FanBridge) == 'undefined')
{
	var FanBridge = function() {};
}


FanBridge.toolbox = {


	connect: function(host, app_key, redirect_url) {
			res = window.open(
				host + '/wordpress/toolbox/v1/?action=connect&app_key=' + app_key + '&redirect_url=' + redirect_url,
				'window_connect',
				'status=0, menubar=0, resizable=0, location=0, width=910, height=495');
	},
	connect_success: function(token) {
		alert('token: ' + token);
	},
	connect_error: function(response) {

	}

}

