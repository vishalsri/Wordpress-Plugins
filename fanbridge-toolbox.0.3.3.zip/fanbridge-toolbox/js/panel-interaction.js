jQuery(document).ready(function() {
						   
	jQuery('a#fan-acquisition').click(function(){
		jQuery(this).addClass('active');
		jQuery('a#fan-questions').removeClass('active');
		jQuery('a#fan-questions').addClass('inactive');
		jQuery('a#events').removeClass('active');
		jQuery('a#events').addClass('inactive');
		
		jQuery('.fan-acquisition-options').show();
		jQuery('.fan-questions-options').hide();
		jQuery('.events-options').hide();
	});
	
	jQuery('a#fan-questions').click(function(){
		jQuery(this).addClass('active');
		jQuery('a#fan-acquisition').removeClass('active');
		jQuery('a#fan-acquisition').addClass('inactive');
		jQuery('a#events').removeClass('active');
		jQuery('a#events').addClass('inactive');
		
		jQuery('.fan-questions-options').show();
		jQuery('.fan-acquisition-options').hide();
		jQuery('.events-options').hide();
	});
	
	jQuery('a#events').click(function(){
		jQuery(this).addClass('active');
		jQuery('a#fan-questions').removeClass('active');
		jQuery('a#fan-questions').addClass('inactive');
		jQuery('a#fan-acquisition').removeClass('active');
		jQuery('a#fan-acquisition').addClass('inactive');
		
		jQuery('.events-options').show();
		jQuery('.fan-questions-options').hide();
		jQuery('.fan-acquisition-options').hide();
	});
	
	jQuery('.widget-theme-options #light').click(function(){
		jQuery(this).addClass('chosen');
		jQuery(this).siblings().removeClass('chosen');	
		saveData();
	});
	
	jQuery('.widget-theme-options #dark').click(function(){
		jQuery(this).addClass('chosen');
		jQuery(this).siblings().removeClass('chosen');
		saveData();
	});
	
	function saveData(){
		//magic stuff happens here
	}

});