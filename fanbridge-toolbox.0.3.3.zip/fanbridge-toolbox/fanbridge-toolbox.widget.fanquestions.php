<?php
/**
 * set the parameters of our plugin to the system
 * 
 * @return void
 */
class FanBridge_ToolBox_Widget_FanQuestions extends WP_Widget {

	function FanBridge_ToolBox_Widget_FanQuestions() {
		$widget_ops = array( 
			'description' => 'Adds a FanBridge FanQuestions widget to yout blog'
		);
		$this->WP_Widget('FanBridge_ToolBox_Widget_FanQuestions', 'FanBridge FanQuestions Widget', $widget_ops);
	}

	public function widget( $args, $instance) {
		if (!is_array($instance)) {
			$instance = array();
		}

		$args['widget_type'] = 'fan_questions';
		fbridge_tb_display_widget(array_merge($args, $instance));
		
	}

	public function form( $instance ) {
		// outputs the options form on admin
	}
}

// Gabriel Sosa and Magali Ickowicz for FanBridge Inc.
// @pendexgabo
// @maguitai
// 2014