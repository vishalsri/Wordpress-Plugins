<?php

// here goes all signup widget functions
require_once dirname(__FILE__) . "/fanbridge-toolbox.widget.signup.php";
// here goes all events widget functions
require_once dirname(__FILE__) . "/fanbridge-toolbox.widget.events.php";
// here goes all fan questions widget functions
require_once dirname(__FILE__) . "/fanbridge-toolbox.widget.fanquestions.php";


/**
 * Displays the presense pixel 
 *
 * @param void
 * @return string; the pixel
 */
function fbridge_tb_pixel($widget_name) {

	if (!do_not_track()) {
		echo "<img style='border:0px' src='//tracking.fanbridge.com/v2/track/image/?bucket=widget&namespace=wpplugin-toolbox-".$widget_name."&event=view&properties%5Buser_id%5D=", get_option(FBTB_PREFIX . FBTB_SN_API_USER_ID), "&properties%5Bwpversion%5D=", get_bloginfo('version'), "&properties%5Bsite%5D=", @$_SERVER["SERVER_NAME"], "&properties%5Bappearance%5D=", (get_option(FBTB_PREFIX . FBTB_CUSTOM_COLORS) == 'on' ? 'custom' : 'theme'), "&properties%5Bplugin_version%5D=", FBTB_PLUGIN_VERSION, "&options%5Bidentity%5D=1&options%5Bsafe_mode%5D=0' width='0' height='0'/>";
	}
}

/**
 * check if the DNT (http://donottrack.us/) header is present
 * in that case we wont print the pixel
 *
 * @link http://robert-lerner.com/do-not-track-headers-in-php.php
 * @param void
 * @return boolean; 
 */
if(!function_exists('do_not_track'))
{
	function do_not_track() {
		if (isset($_SERVER['HTTP_DNT'])) {
			if ($_SERVER['HTTP_DNT'] == 1) {
				return true;
			}
		}
		elseif(function_exists('getallheaders')) {
			foreach (getallheaders() as $k => $v) {
				if (strtolower($k) === "dnt" && $v == 1) {
					return true;
				}
			}
		}
		return false;
	}

}

/**
 * displays the widget based on the parameters sent to
 *
 * @return void
 */
function fbridge_tb_display_widget($args) {

	$widget_type = $args['widget_type'];

	if($widget_type == 'fan_questions')
	{
		$widget_data_option_id = FBTB_PREFIX . FBTB_FAN_QUESTIONS;
		$widget_id_option_id = FBTB_PREFIX . FBTB_FQ_WIDGET_ID;
	}
	elseif($widget_type == 'events')
	{
		$widget_data_option_id = FBTB_PREFIX . FBTB_EVENTS;
		$widget_id_option_id = FBTB_PREFIX . FBTB_EVENTS_WIDGET_ID;
	}
	else
	{
		throw new Exception("Ivalid widget type", 1);
		
	}

	$cached_time = get_option($widget_data_option_id . '_' . FBTB_CACHED_TIME);
	$widget_data = get_option($widget_data_option_id);

	if((!$cached_time) || (!$widget_data) || ($cached_time <= (time() - FBTB_CACHING_TIME)))
	{

		$widget_id = get_option($widget_id_option_id);
		if(!$widget_id)
		{
			//undefined widget id, nothing to show
			return '';
		}

		$secret = get_option(FBTB_PREFIX . FBTB_SN_API_SECRET);
		$token = get_option(FBTB_PREFIX . FBTB_SN_API_TOKEN);

		if(!$secret || !$token)
		{
			throw new Exception("Error connecting to FanBridge API");
		}

		try{
			$fanbridge_api = new Fanbridge_Api(array( 
					'secret' => $secret, 
					'token' => $token));
			$widget_data = $fanbridge_api->call('widget/fetch', array('id' => $widget_id));
			$widget_data = json_decode($widget_data, true);

		} catch (Exception $e) {
			throw new Exception("Error connecting to FanBridge API");
		}

		update_option($widget_data_option_id, $widget_data);
		update_option($widget_data_option_id . '_' . FBTB_CACHED_TIME, time());
	}
	$out = "<div>";
	$out .= $widget_data['embed'];
	$out .= fbridge_tb_pixel($widget_type);
	$out .= "</div>";
	echo $out;

}

/**
 * prints the css which makes the form grab inherit styles from the blog theme
 *
 * @return string
 */
function fbridge_tb_inherit_css() {
?>

/* inherit */
/* IE Fixes */

.ie .textInput {
	line-height: 35px;
}


/* Resets */

#FbridgeTBSGWidget fieldset,
#FbridgeTBSGWidget h2,
#FbridgeTBSGWidget,
#FbridgeTBSGWidget .textInput,
#FbridgeTBSGWidget .button {
	width: 100% !important;
}

#FbridgeTBSGWidget * {
	text-transform: none !important;
	background-image: none !important;
	text-indent: 0 !important;
	word-wrap: normal !important;
}

#FbridgeTBSGWidget fieldset {
	box-sizing: border-box;
	-moz-box-sizing: border-box; // for Mozilla
	-webkit-box-sizing: border-box; // for WebKit
	-ms-box-sizing: border-box; // for IE8
	background-color: inherit;
	width: 100% !important;
	border: 0px !important;
	padding: 0px !important;
	margin: 0px !important;
	font-size: inherit !important;
	-webkit-margin-start: 0;
	-webkit-padding-start: 0;
	-webkit-margin-end: 0;
	-webkit-padding-end: 0;
	-webkit-padding-before: 0;
	-webkit-padding-after: 0;
	-webkit-margin: 0px;
	-webkit-padding: 0px;
}

#FbridgeTBSGWidget .selectInput {
	height: 35px !important;
	margin: 0px 0px 30px 0px !important;
	padding: 0px !important;
	line-height: 10px !important;
	vertical-align: center !important;
	}

#FbridgeTBSGWidget .textInput:focus,
#FbridgeTBSGWidget .emailInput:focus,
#FbridgeTBSGWidget input[type=submit]:focus {
	outline: none !important;
}

#FbridgeTBSGWidget input[type=submit],
#FbridgeTBSGWidget input[type=text] {
	-webkit-appearance: none !important;
}

#FbridgeTBSGWidget input::-moz-focus-inner /*Remove button padding in FF*/
{ 
    border: 0 !important;
    padding: 0 !important;
}

/* Styling */


#FbridgeTBSGWidget {
	box-sizing: border-box;
	-moz-box-sizing: border-box; // for Mozilla
	-webkit-box-sizing: border-box; // for WebKit
	-ms-box-sizing: border-box; // for IE8
	font-size: 1em !important;
	background-color: inherit !important;
	color: inherit !important;
	width: 100% !important;
	-moz-border-radius: 3px !important;
	-webkit-border-radius: 3px !important;
	border-radius: 5px !important;
	margin: 0px 0px 15px 0px !important;
}

#FbridgeTBSGWidget .textInput,
#FbridgeTBSGWidget .selectInput,
#FbridgeTBSGWidget .button {
	-moz-border-radius: 3px !important;
	-webkit-border-radius: 3px !important;
	border-radius: 3px !important;
}

#FbridgeTBSGWidget .textInput,
#FbridgeTBSGWidget .selectInput {
	border: 1px solid inherit !important;
}

#FbridgeTBSGWidget label {
	border: 0px !important;
	padding: 0px !important;
	margin-bottom: 5px !important;
}

#FbridgeTBSGWidget h2 {
	font-size: 1.8em !important;
	border: 0px !important;
	margin: 0px 0px 13px 0px !important;
	padding: 0px !important;
	line-height: 1.2em !important;
	text-align: left !important;
}

#FbridgeTBSGWidget #errorField,
#FbridgeTBSGWidget #attribution {
	font-size: .9em !important;
}

#FbridgeTBSGWidget #errorField {
	color: #d42932 !important;
	margin-bottom: 12px !important;
}

#FbridgeTBSGWidget #errorField p {
	margin: 0px !important;
	padding: 0px !important;
	border: 0px !important;
}

#FbridgeTBSGWidget .invalid {
	border: 1% solid #d42932 !important;
	box-shadow: inset 0px 0px 0px 2px #d42932 !important;
}


#FbridgeTBSGWidget #attribution {
	margin-bottom: -15px !important;
}


#FbridgeTBSGWidget label,
#FbridgeTBSGWidget input{
	display: block !important;
}

#FbridgeTBSGWidget a {
	display: block !important;
	margin: 10px 0px 10px 0px !important;
}

#FbridgeTBSGWidget a:hover {
	display: block !important;
	text-decoration: underline !important;
}


#FbridgeTBSGWidget input[type=text] {
	box-sizing: border-box;
	-moz-box-sizing: border-box; // for Mozilla
	-webkit-box-sizing: border-box; // for WebKit
	-ms-box-sizing: border-box; // for IE8
	font-size: inherit;
	padding: 0px 8px 0px 8px !important;
	margin-bottom: 13px !important;
	width: 100% !important;
	height: 35px !important;
	vertical-align: bottom !important;
	font-family: inherit !important;
	font-size: inherit !important;
	color: #333333 !important;
	background-color: #fff !important;
}

#FbridgeTBSGWidget .selectInput {
	box-sizing: border-box;
	-moz-box-sizing: border-box; // for Mozilla
	-webkit-box-sizing: border-box; // for WebKit
	-ms-box-sizing: border-box; // for IE8
	font-size: inherit;
	padding: 8px 0 8px 5px !important;
	margin-bottom: 13px !important;
	width: 100% !important;
	height: 35px !important;
	vertical-align: bottom !important;
	font-family: inherit !important;
	font-size: inherit !important;
	color: #333333 !important;
	background-color: #fff !important;
}


#FbridgeTBSGWidget .button{
	vertical-align: baseline !important;
	color: white !important;
	width: 100% !important;
	font-family: inherit;
	font-weight: bold !important;
	background-color: #000 !important;
	background-image: none !important;
	height: auto !important;
	border: none !important;
	padding: 12px 0px 14px 0px !important;
	cursor: pointer !important;
	filter: alpha(opacity=30);
	-moz-opacity:0.30;
	opacity: .30;	
	transition: opacity .2s;
	-moz-transition: opacity .2s; /* Firefox 4 */
	-webkit-transition: opacity .2s; /* Safari and Chrome */
	-o-transition: opacity .2s; /* Opera */

}

#FbridgeTBSGWidget .button:focus,
#FbridgeTBSGWidget .button:hover {
	filter: alpha(opacity=40);
	-moz-opacity:0.40;
	opacity: .40;	
}

#FbridgeTBSGWidget .selectInputBirthdateDay {
	
	width:55px!important;
}

#FbridgeTBSGWidget .selectInputBirthdateMonth {
	
	width:50px!important;
}

#FbridgeTBSGWidget .selectInputBirthdateYear {
	
	width:65px!important;
}

/*----------------------- widget recaptcha --------------------*/
#FbridgeTBSGWidget #recaptcha_widget{position: relative;}
#FbridgeTBSGWidget #recaptcha_widget a{
	display:inline!important;
}
#FbridgeTBSGWidget #recaptcha_widget p{
    position: absolute;
    text-align: center;
    top: -25px;
    left: 11px;
    width: 100%;
    font-family: "HelveticaNeueRegular","Myriad Pro";
    font-size: 14px;
    color: #6A6A6A;
}
#FbridgeTBSGWidget #recaptcha_image{
    width: 200px !important;
    height: 30px !important;
} 
#FbridgeTBSGWidget #recaptcha_image img{
    width: 100%!important;
    height: auto!important;
    background-color: #F0F0F0;
    border-color: 1px solid #DDDDDD;
}
#FbridgeTBSGWidget #recaptcha_response_field{
    height: 30px;
    width: 210px;
    margin: 0 0 0 3px;
    padding: 5px 27px 5px 5px;
    background-color: #F0F0F0;
    border-color: #DDDDDD;
    font-size: 15px;
    display:inline!important;
}

<?php
}


/**
 * prints the css which makes the form to use the color schema chosen by the
 * user
 *
 * @param $highlight_color string; the custom color chosen by the user
 * @return string
 */
function fbridge_tb_custom_css($highlight_color) {
	?>
/*  custom */
/* IE Fixes */

.ie .textInput {
	line-height: 35px;
}


/* Resets */

#FbridgeTBSGWidget * {
	text-transform: none !important;
	background-image: none !important;
	text-indent: 0 !important;
	word-wrap: normal !important;
	letter-spacing: normal !important;
	word-break: normal !important;
	box-shadow: none !important;
	text-align: left !important;
}



#FbridgeTBSGWidget fieldset {
	box-sizing: border-box;
	-moz-box-sizing: border-box; // for Mozilla
	-webkit-box-sizing: border-box; // for WebKit
	-ms-box-sizing: border-box; // for IE8
	padding: 0px;
	margin: 0px;
	-webkit-margin-start: 0;
	-webkit-padding-start: 0;
	-webkit-margin-end: 0;
	-webkit-padding-end: 0;
	-webkit-padding-before: 0;
	-webkit-padding-after: 0;
	-webkit-margin: 0px;
	-webkit-padding: 0px;
	border: 0px !important;
	background-color: #fff !important;
}

#FbridgeTBSGWidget .textInput:focus,
#FbridgeTBSGWidget .selectInput,
#FbridgeTBSGWidget .emailInput:focus,
#FbridgeTBSGWidget input[type=submit]:focus {
	outline: none;
}

#FbridgeTBSGWidget input[type=submit],
#FbridgeTBSGWidget input[type=text] {
	-webkit-appearance: none;
}

#FbridgeTBSGWidget input::-moz-focus-inner /*Remove button padding in FF*/
{ 
    border: 0;
    padding: 0;
}

/* Styling */

#FbridgeTBSGWidget {
	box-sizing: border-box;
	-moz-box-sizing: border-box; // for Mozilla
	-webkit-box-sizing: border-box; // for WebKit
	-ms-box-sizing: border-box; // for IE8
	font-size: 14px !important;
	line-height: 15px !important;
	background-color: white !important;
	color: #333333 !important;
	padding: 15px !important;
	-moz-border-radius: 3px !important;
	-webkit-border-radius: 3px !important;
	border-radius: 5px !important;
	margin: 0px 0px 15px 0px !important;
}

#FbridgeTBSGWidget .textInput,
#FbridgeTBSGWidget .selectInput,
#FbridgeTBSGWidget .button {
	-moz-border-radius: 3px !important;
	-webkit-border-radius: 3px !important;
	border-radius: 3px !important;
}

#FbridgeTBSGWidget .textInput,
#FbridgeTBSGWidget .selectInput,
#FbridgeTBSGWidget  {
	border: 1px solid #C5C5C5 !important;
}

#FbridgeTBSGWidget label {
	color: #333333 !important;
	margin-bottom: 5px !important;
}

#FbridgeTBSGWidget h2 {
	font-family: 'georgia', 'cambria', 'sans serif' !important;
	background-color: #fff !important;
	color: <?= $highlight_color ?> !important;
	height: auto !important;
	font-weight: normal !important;
    	border: 0 !important;
	line-height: 25px !important;
	font-size: 24px !important;
	text-align: left !important;
	padding: 0px !important;
}

#FbridgeTBSGWidget h2,
#FbridgeTBSGWidget .textInput,
#FbridgeTBSGWidget .selectInput,
#FbridgeTBSGWidget .button {
	margin: 0px 0px 13px 0px !important;
}


#FbridgeTBSGWidget #errorField,
#FbridgeTBSGWidget #attribution {
	font-weight: bold !important;
	font-size: 12px !important;
}

#FbridgeTBSGWidget #errorField {
	color: #d42932 !important;
	margin-bottom: 12px !important;
}

#FbridgeTBSGWidget #errorField p {
	margin: 0px !important;
}

#FbridgeTBSGWidget .invalid {
	border: 1% solid #d42932 !important;
	box-shadow: inset 0px 0px 0px 2px #d42932 !important;
}


#FbridgeTBSGWidget #attribution {
	margin-bottom: -15px !important;
	color: #9E9E9E !important;
}

#FbridgeTBSGWidget a {
	background-color: none !important;
	padding: 0 !important;
	color: #9E9E9E !important;
	display: block !important;
	text-decoration: none !important;
	margin: 10px 0px 10px 0px !important;
	border: 0px !important;
	text-align: center !important;
}

#FbridgeTBSGWidget a:hover {
	background-color: none !important;
	color: #333333 !important;
}

#FbridgeTBSGWidget label,
#FbridgeTBSGWidget input{
	display: block;
}

#FbridgeTBSGWidget .textInput {
	box-sizing: border-box;
	-moz-box-sizing: border-box; // for Mozilla
	-webkit-box-sizing: border-box; // for WebKit
	-ms-box-sizing: border-box; // for IE8
	font-weight: normal !important;
	color: #333333 !important;
	background-color: #fff !important;
	background: none !important;
	padding: 0px 8px 0px 8px !important;
	height: 35px !important;
	vertical-align: bottom !important;
	font-family: 'Helvetica', 'Arial', 'Sans-serif' !important;
}

#FbridgeTBSGWidget .selectInput {
	box-sizing: border-box;
	-moz-box-sizing: border-box; // for Mozilla
	-webkit-box-sizing: border-box; // for WebKit
	-ms-box-sizing: border-box; // for IE8
	font-weight: normal !important;
	color: #333333 !important;
	background-color: #fff !important;
	background: none !important;
	padding: 8px 0 8px 5px !important;
	height: 35px !important;
	vertical-align: bottom !important;
	font-family: 'Helvetica', 'Arial', 'Sans-serif' !important;
}

#FbridgeTBSGWidget .textInput,
#FbridgeTBSGWidget .button,
#FbridgeTBSGWidget label,
#FbridgeTBSGWidget a,
#FbridgeTBSGWidget #attribution,
#FbridgeTBSGWidget #errorField,
#FbridgeTBSGWidget .textInput,
#FbridgeTBSGWidget .selectInput,
#FbridgeTBSGWidget {
	font-family: 'Helvetica', 'Arial', 'Sans-serif' !important;
}

#FbridgeTBSGWidget fieldset,
#FbridgeTBSGWidget h2,
#FbridgeTBSGWidget,
#FbridgeTBSGWidget .textInput,
#FbridgeTBSGWidget .selectInput,
#FbridgeTBSGWidget .button {
	width: 100% !important;
}

#FbridgeTBSGWidget .button,
#FbridgeTBSGWidget label,
#FbridgeTBSGWidget .textInput,
#FbridgeTBSGWidget .selectInput,
#FbridgeTBSGWidget {
	font-size: 14px !important;
}

#FbridgeTBSGWidget .button,
#FbridgeTBSGWidget #attribution {
	text-align: center !important;
}

#FbridgeTBSGWidget a,
#FbridgeTBSGWidget #attribution,
#FbridgeTBSGWidget #errorField {
	background-color: none !important;
	font-size: 12px !important;

}

#FbridgeTBSGWidget .button{
	background-image: none !important;
	height: auto !important;
	vertical-align: baseline !important;
	color: white !important;
	font-size: 14px !important;
	font-weight: bold !important;
	background-color: <?= $highlight_color ?> !important;
	border: none !important;
	padding: 10px 0px 10px 0px !important;
	cursor: pointer !important;
	transition: opacity .2s !important;
	-moz-transition: opacity .2s; /* Firefox 4 */
	-webkit-transition: opacity .2s; /* Safari and Chrome */
	-o-transition: opacity .2s; /* Opera */

}

#FbridgeTBSGWidget .button:focus,
#FbridgeTBSGWidget .button:hover {
	filter: alpha(opacity=85);
	-moz-opacity:0.85;
	opacity: .85;	
}

#FbridgeTBSGWidget .selectInputBirthdateDay {
	
	width:55px!important;
}

#FbridgeTBSGWidget .selectInputBirthdateMonth {
	
	width:50px!important;
}

#FbridgeTBSGWidget .selectInputBirthdateYear {
	
	width:65px!important;
}
/*----------------------- widget recaptcha --------------------*/
#FbridgeTBSGWidget #recaptcha_widget{position: relative;}
#FbridgeTBSGWidget #recaptcha_widget a{
	display:inline!important;
}
#FbridgeTBSGWidget #recaptcha_widget p{
    position: absolute;
    text-align: center;
    top: -25px;
    left: 11px;
    width: 100%;
    font-family: "HelveticaNeueRegular","Myriad Pro";
    font-size: 14px;
    color: #6A6A6A;
}
#FbridgeTBSGWidget #recaptcha_image{
    width: 200px !important;
    height: 30px !important;
} 
#FbridgeTBSGWidget #recaptcha_image img{
    width: 100%!important;
    height: auto!important;
    background-color: #F0F0F0;
    border-color: 1px solid #DDDDDD;
}
#FbridgeTBSGWidget #recaptcha_response_field{
    height: 30px;
    width: 210px;
    margin: 0 0 0 3px;
    padding: 5px 27px 5px 5px;
    background-color: #F0F0F0;
    border-color: #DDDDDD;
    font-size: 15px;
    display:inline!important;
}


<?php	
}


// Gabriel Sosa and Magali Ickowicz for FanBridge Inc.
// @pendexgabo
// @maguitai
// 2014