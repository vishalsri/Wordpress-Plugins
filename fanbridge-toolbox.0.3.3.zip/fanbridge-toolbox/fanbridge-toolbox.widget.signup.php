<?php

//  ______          ____       _     _            
// |  ____|        |  _ \     (_)   | |           
// | |__ __ _ _ __ | |_) |_ __ _  __| | __ _  ___ 
// |  __/ _` | '_ \|  _ <| '__| |/ _` |/ _` |/ _ \
// | | | (_| | | | | |_) | |  | | (_| | (_| |  __/
// |_|  \__,_|_| |_|____/|_|  |_|\__,_|\__, |\___|
//                                      __/ |     
//                                     |___/      

/**
 * set the parameters of our plugin to the system
 * 
 * @return void
 */
class FanBridge_ToolBox_Widget_SignUp extends WP_Widget {

	function FanBridge_ToolBox_Widget_SignUp() {
		$widget_ops = array( 
			'description' => 'Adds a FanBridge signup form to your blog'
		);
		$this->WP_Widget('FanBridge_ToolBox_Widget_SignUp', 'FanBridge signup Widget', $widget_ops);
	}

	public function widget($args, $instance) {

		if (!is_array($instance)) {
			$instance = array();
		}

		fbridge_tb_signup_form(array_merge($args, $instance));
	}
}

/**
 * displays the form based on the parameters sent to
 * FanBridge_ToolBox_Widget_SignUp
 *
 * @return string
 */
function fbridge_tb_signup_form($args) {

	$groups = get_option(FBTB_PREFIX . FBTB_SN_GROUP);
	$user_id = get_option(FBTB_PREFIX . FBTB_SN_API_USER_ID);

	if (!$user_id) {
		// if we dont have the user id there isn't much to show
		return '';
	}

	?>
	<form method="post" id="FbridgeTBSGWidget" action="<?= get_schema() . FBTB_SUBSCRIBE_ENDPOINT ?>?userid=<?= $user_id ?>">
		<h2><?= get_option(FBTB_PREFIX . FBTB_SN_FORM_TITLE) ?></h2>
		<fieldset>
			<label>Email Address:</label>
			<input type="text" class="textInput" id="<?= FBTB_PREFIX .  FBTB_SN_EMAIL ?>" name="<?= FBTB_PREFIX . FBTB_SN_EMAIL ?>" value=""/>

			<?php if (get_option(FBTB_PREFIX . FBTB_SN_FIRST_NAME . '_show') == 'on') :?>
			<label>First Name:</label>
			<input type="text" class="textInput" id="<?= FBTB_PREFIX .  FBTB_SN_FIRST_NAME ?>" name="<?= FBTB_PREFIX . FBTB_SN_FIRST_NAME ?>" value=""/>
			<?php endif; ?>

			<?php if (get_option(FBTB_PREFIX . FBTB_SN_LAST_NAME . '_show') == 'on') :?>
			<label>Last Name:</label>
			<input type="text" class="textInput" id="<?= FBTB_PREFIX .  FBTB_SN_LAST_NAME ?>" name="<?= FBTB_PREFIX . FBTB_SN_LAST_NAME ?>" value=""/>
			<?php endif; ?>

			<?php if (get_option(FBTB_PREFIX . FBTB_SN_ZIP_CODE . '_show') == 'on') :?>
			<label>Zip/Postal Code:</label>
			<input type="text" class="textInput" id="<?= FBTB_PREFIX .  FBTB_SN_ZIP_CODE ?>" name="<?= FBTB_PREFIX . FBTB_SN_ZIP_CODE ?>" value=""/>
			<?php endif; ?>

			<?php if (get_option(FBTB_PREFIX . FBTB_SN_CITY . '_show') == 'on') :?>
			<label>City:</label>
			<input type="text" class="textInput" id="<?= FBTB_PREFIX .  FBTB_SN_CITY ?>" name="<?= FBTB_PREFIX . FBTB_SN_CITY ?>" value=""/>
			<?php endif; ?>

			<?php if (get_option(FBTB_PREFIX . FBTB_SN_STATE . '_show') == 'on') :?>
			<label>State/Region:</label>
			<input type="text" class="textInput" id="<?= FBTB_PREFIX .  FBTB_SN_STATE ?>" name="<?= FBTB_PREFIX . FBTB_SN_STATE ?>" value=""/>
			<?php endif; ?>

			<?php if (get_option(FBTB_PREFIX . FBTB_SN_COUNTRY . '_show') == 'on') :?>
			<label>Country:</label>
			<select class="selectInput" id="<?= FBTB_PREFIX .  FBTB_SN_COUNTRY ?>" name="<?= FBTB_PREFIX . FBTB_SN_COUNTRY ?>">
				<option value="0" data-iso="">-- SELECT COUNTRY --</option>
					<?php country_select() ?>
			</select>
			<?php endif; ?>
			<?php if (get_option(FBTB_PREFIX . FBTB_SN_BIRTHDATE . '_show') == 'on') :?>
			<label>Birthdate:</label>
			<select class="selectInput selectInputBirthdateMonth" id="<?= FBTB_PREFIX .  FBTB_SN_BIRTHDATE_MONTH ?>" name="<?= FBTB_PREFIX . FBTB_SN_BIRTHDATE_MONTH ?>">
				<option value="0">MM</option>
				<?php birthdate_month_select() ?>
			</select>
			<select class="selectInput selectInputBirthdateDay" id="<?= FBTB_PREFIX .  FBTB_SN_BIRTHDATE_DAY ?>" name="<?= FBTB_PREFIX . FBTB_SN_BIRTHDATE_DAY ?>">
				<option value="0">DD</option>
				<?php birthdate_day_select() ?>
			</select>
			<select class="selectInput selectInputBirthdateYear" id="<?= FBTB_PREFIX .  FBTB_SN_BIRTHDATE_YEAR ?>" name="<?= FBTB_PREFIX . FBTB_SN_BIRTHDATE_YEAR ?>">
				<option value="0">YYYY</option>
				<?php birthdate_year_select() ?>
			</select>
			<?php endif; ?>

			<?php if ($groups) :?>
				<label>Select a group you’d like to join:</label>
				<?php foreach($groups as $group_id => $group) :?>
					<div>
						<div style="float:left;">
							<input type="checkbox" id="<?= FBTB_PREFIX .  FBTB_SN_GROUP ?>_<?=$group_id;?>" name="<?= FBTB_PREFIX .  FBTB_SN_GROUP ?>[<?=$group_id;?>]" value="<?=$group_id;?>" />
						</div>
						<div style="float:left;">
							<?= $group["name"];?>
						</div>
						<br clear="both" />
					</div>
				<?php endforeach; ?>
			<?php endif;?>
			<div id="<?php echo FBTB_PREFIX .  FBTB_SN_CAPTCHA_DIV ?>" name="<?php echo FBTB_PREFIX . FBTB_SN_CAPTCHA_DIV ?>"></div>



		</fieldset>
		<div id="errorField">
		</div>
		<input type="submit" id="_submit-input" name="_submit" class="button" value="Join Mailing List" />
		<div id="attribution">
			<a href="http://<?= FBTB_SITE_URL ?>/?src=fb_wordpress_tb_signup_form&utm_source=wordpress&utm_medium=signup_form&utm_campaign=tb_plugin&utm_content=<?= $user_id ?>" target="_blank">Powered by FanBridge</a>
		</div>
		<input id="<?= FBTB_PREFIX .  'agent' ?>" name="<?= FBTB_PREFIX .  'agent' ?>" value="<?= FBTB_PLUGIN_NAME .'-v' . FBTB_PLUGIN_VERSION ?>" type="hidden"/>
		<?php fbridge_tb_pixel('signup'); ?>
	</form>
	<?php	

	fbridge_tb_js();	
	load_recaptcha_script();

?>

<?php
}

/**
 * displays the required js to make the widget working
 *
 * @return string
 */
function fbridge_tb_js() {
?>
<!-- fanbridge widget required js -->
<script type="text/javascript">
/* <![CDATA[ */
	(function($){
		// some defaults
		var _fbridge_sw_prefix = '<?= FBTB_PREFIX ?>';
		var $fbridge_sw_form = $('#FbridgeTBSGWidget');
		var $fbridge_sw_result = $('#errorField');

		<?php if (get_option(FBTB_PREFIX . FBTB_SN_BIRTHDATE . '_required') == 'on') :?>
			$.validator.addMethod("FullDate", function() {
			    if($("#<?php echo FBTB_PREFIX .  FBTB_SN_BIRTHDATE_DAY;?>").val() != 0 && $("#<?php echo FBTB_PREFIX .  FBTB_SN_BIRTHDATE_MONTH;?>").val() != 0 && $("#<?php echo FBTB_PREFIX .  FBTB_SN_BIRTHDATE_YEAR;?>").val() != 0)
			    {
			      	return true;
			    }
			    else
			    {
			      	return false;
			    }
			}, 'You did not enter a correct birth date');
			$.validator.addMethod("check_date_of_birth", function(value, element, params) {

			    var day = $("#<?php echo FBTB_PREFIX .  FBTB_SN_BIRTHDATE_DAY;?>").val();
			    var month = $("#<?php echo FBTB_PREFIX .  FBTB_SN_BIRTHDATE_MONTH;?>").val();
			    var year = $("#<?php echo FBTB_PREFIX .  FBTB_SN_BIRTHDATE_YEAR;?>").val();
			    var age =  params.age
			    if(typeof age == undefined)
			    {
			    	return false;
			    }

			    var mydate = new Date();
			    mydate.setFullYear(year, month-1, day);

			    var currdate = new Date();
			    currdate.setFullYear(currdate.getFullYear() - age);

			    return currdate > mydate;

			}, "You must be at least <?php echo FBTB_SN_COPPA_COMPLIANT_AGE; ?> years of age.");
		<?php endif; ?>     


		$fbridge_sw_form.validate({
			onfocusout: false,
			onkeyup: false,
			errorClass: 'invalid',
			showErrors: function(errorMap, errorList) {
				$('.invalid').removeClass('invalid');
				var birthdate_error_present = false;
           		$.each(errorList, function(key, val) {
					$(val.element).addClass('invalid');
				});
           		$fbridge_sw_result.html('Invalid entries. Please correct the highlighted fields.');
           		<?php if(get_option(FBTB_PREFIX.FBTB_SN_COPPA_COMPLIANT)):?>
	           		if('<?php echo FBTB_PREFIX .  FBTB_SN_BIRTHDATE_DAY ?>' in errorMap)
	           		{
					   $fbridge_sw_result.html(errorMap["<?php echo FBTB_PREFIX .  FBTB_SN_BIRTHDATE_DAY;?>"]+"<br/>"+$fbridge_sw_result.html());
					   $("#<?php echo FBTB_PREFIX .  FBTB_SN_BIRTHDATE_MONTH ?>").addClass('invalid');
					   $("#<?php echo FBTB_PREFIX .  FBTB_SN_BIRTHDATE_YEAR ?>").addClass('invalid');
					};
				<?php endif; ?>
	        },
			unhighlight: function(element, errorClass) {
				$(element).removeClass('invalid');
     			$fbridge_sw_result.html('');
     		},
			rules: {
				<?= FBTB_PREFIX .  FBTB_SN_EMAIL ?>: {
       				required: true,
       				email: true
     			}
       			<?php if (get_option(FBTB_PREFIX . FBTB_SN_FIRST_NAME . '_required') == 'on') :?>
				,<?= FBTB_PREFIX .  FBTB_SN_FIRST_NAME ?>: {
       				required: true
     			}
       			<?php endif; ?>     			
       			<?php if (get_option(FBTB_PREFIX . FBTB_SN_LAST_NAME . '_required') == 'on') :?>
				,<?= FBTB_PREFIX .  FBTB_SN_LAST_NAME ?>: {
       				required: true
     			}
       			<?php endif; ?>     
       			<?php if (get_option(FBTB_PREFIX . FBTB_SN_ZIP_CODE . '_required') == 'on') :?>
				,<?= FBTB_PREFIX .  FBTB_SN_ZIP_CODE ?>: {
       				required: true
     			}
       			<?php endif; ?>
       			<?php if (get_option(FBTB_PREFIX . FBTB_SN_CITY . '_required') == 'on') :?>
				,<?= FBTB_PREFIX .  FBTB_SN_CITY ?>: {
       				required: true
     			}
       			<?php endif; ?>     
       			<?php if (get_option(FBTB_PREFIX . FBTB_SN_STATE . '_required') == 'on') :?>
				,<?= FBTB_PREFIX .  FBTB_SN_STATE ?>: {
       				required: true
     			}
       			<?php endif; ?>     
       			<?php if (get_option(FBTB_PREFIX . FBTB_SN_COUNTRY . '_required') == 'on') :?>
				,<?= FBTB_PREFIX .  FBTB_SN_COUNTRY ?>: {
       				min: 1
     			}
       			<?php endif; ?>  
       			<?php if (get_option(FBTB_PREFIX . FBTB_SN_BIRTHDATE . '_required') == 'on') :?>
				,<?php echo FBTB_PREFIX .  FBTB_SN_BIRTHDATE_DAY ?>: {
       				FullDate: true
       				<?php if(get_option(FBTB_PREFIX.FBTB_SN_COPPA_COMPLIANT) == 'on'):?>
	       				,check_date_of_birth: {
	       					age: <?php echo FBTB_SN_COPPA_COMPLIANT_AGE; ?>
	       				}
	       			<?php endif;?>
     			}
       			<?php endif; ?>   

			},
			submitHandler: function() {

				$("#FbridgeTBSGWidget .textInput").removeClass('invalid');
				$fbridge_sw_result.html('');

				// remove the namespace
				var _data = {};
				$.each($fbridge_sw_form.serializeArray(), function(n, each) {
	  				_data[each.name.replace(_fbridge_sw_prefix, '')] = each.value;
				});

				$.ajax({
					url: '<?= get_schema() . FBTB_SUBSCRIBE_ENDPOINT ?>?response=json&userid=<?= get_option(FBTB_PREFIX . FBTB_SN_API_USER_ID) ?>',
					data: _data,
					dataType:"jsonp",
					beforeSubmit: function() {
						$fbridge_sw_result.html('');
						$('#_submit-input').attr('disabled', true);
					},
					success: function(res, status, xobj) {
						if(res.status == 'error') {
							$('#_submit-input').attr('disabled', false);
							var challenge_display = false;
							$.each(res.data.fields, function(key, val) {
								if(key == 'challenge-display')
			                	{
			                		challenge_display = true;
			                		return;
			                	}
			                	else if(key == 'challenge-incorrect-sol')
			                	{
			                		if($('#recaptcha_widget').length)
			                		{
			                			Recaptcha.reload();
			                			$('#recaptcha_response_field').addClass('error');
			                		}
			                	}

								$fbridge_sw_result.html('');
								$('#' + _fbridge_sw_prefix + key).addClass('invalid');
								$fbridge_sw_result.html($fbridge_sw_result.html() + ' ' + val);
							});

							if(challenge_display)
			                {
			                	showRecaptcha('<?php echo FBTB_PREFIX .  FBTB_SN_CAPTCHA_DIV ?>');
			                }

						}
						else if(res.status == 'ok') {
							// just being nice
							$('#_submit-input').val('Subscribed!');
							setTimeout(function() {
								$('#_submit-input').val('Join Mailing List');
								$fbridge_sw_form.each (function() { this.reset(); });
								if($('#recaptcha_widget').length)
								{
									Recaptcha.reload();
								}
							}, 3000);
						}
					},
					error: function() {
							$fbridge_sw_result.html('Oops! An unexpected error ocurred. Please try again.');
					}
				});
			}
		});

		<?php if (get_option(FBTB_PREFIX . FBTB_SN_GEOIP) == 'on') :?>
		// get the geodata based on the client ip
		$.ajax({
			url: '//geo-ip.herokuapp.com/location.json',
			dataType:"jsonp" ,
			success: function(data) {
				$('#<?= FBTB_PREFIX .  FBTB_SN_ZIP_CODE ?>').val(data.postal_code);
				$('#<?= FBTB_PREFIX .  FBTB_SN_CITY ?>').val(data.city);
				$('#<?= FBTB_PREFIX .  FBTB_SN_STATE ?>').val(data.region_name);
				$("#<?= FBTB_PREFIX .  FBTB_SN_COUNTRY ?> option[data-iso='" + data.country_code + "']").attr("selected","selected");

			}
		});
		<?php endif; ?> 

		function showRecaptcha(element) {

		 	var recaptcha_element = '<div id="recaptcha_widget" class="clearfix">' +
	                 					'<div id="recaptcha_image"></div><br/>' +
	                 					'<div>' +
	                 					'<input type="text" id="recaptcha_response_field" name="recaptcha_response_field" />' +
	                 					'<a href="javascript:Recaptcha.reload()"><img src="<?php echo WP_PLUGIN_URL;?>/fanbridge-toolbox/img/reload.png"></a>' +
	                 					'<br clear="both"/></div>' +
	                 				'</div>';

		    $('#'+element).html(recaptcha_element);

		    Recaptcha.create('<?php echo FB_RECAPTCHA_PUBLIC_KEY;?>',
		        element,
		        {
		          theme: "custom",
		          callback: Recaptcha.focus_response_field,
		          custom_theme_widget: 'recaptcha_widget'
		        }
		    );
		}

	})(jQuery);
/* ]]> */
</script>
<!-- // fanbridge widget required js -->
<?php

}

if (!function_exists('country_select'))
{

	/**
	 * 
	 */
	function country_select() {

		// guess what! a country list!
		$countries["US"] = array("id" => 1, "name" => "UNITED STATES");
		$countries["PA"] = array("id" => 155, "name" => "PANAMA");
		$countries["PW"] = array("id" => 154, "name" => "PALAU");
		$countries["PK"] = array("id" => 153, "name" => "PAKISTAN");
		$countries["OM"] = array("id" => 152, "name" => "OMAN");
		$countries["NO"] = array("id" => 151, "name" => "NORWAY");
		$countries["MP"] = array("id" => 150, "name" => "NORTHERN MARIANA ISLANDS");
		$countries["NF"] = array("id" => 149, "name" => "NORFOLK ISLAND");
		$countries["NU"] = array("id" => 148, "name" => "NIUE");
		$countries["NG"] = array("id" => 147, "name" => "NIGERIA");
		$countries["NE"] = array("id" => 146, "name" => "NIGER");
		$countries["NI"] = array("id" => 145, "name" => "NICARAGUA");
		$countries["NZ"] = array("id" => 144, "name" => "NEW ZEALAND");
		$countries["PG"] = array("id" => 156, "name" => "PAPUA NEW GUINEA");
		$countries["PY"] = array("id" => 157, "name" => "PARAGUAY");
		$countries["PE"] = array("id" => 158, "name" => "PERU");
		$countries["KN"] = array("id" => 170, "name" => "SAINT KITTS AND NEVIS");
		$countries["SH"] = array("id" => 169, "name" => "SAINT HELENA");
		$countries["RW"] = array("id" => 168, "name" => "RWANDA");
		$countries["RU"] = array("id" => 167, "name" => "RUSSIAN FEDERATION");
		$countries["RO"] = array("id" => 166, "name" => "ROMANIA");
		$countries["RE"] = array("id" => 165, "name" => "REUNION");
		$countries["QA"] = array("id" => 164, "name" => "QATAR");
		$countries["PR"] = array("id" => 163, "name" => "PUERTO RICO");
		$countries["PT"] = array("id" => 162, "name" => "PORTUGAL");
		$countries["PL"] = array("id" => 161, "name" => "POLAND");
		$countries["PN"] = array("id" => 160, "name" => "PITCAIRN");
		$countries["PH"] = array("id" => 159, "name" => "PHILIPPINES");
		$countries["NC"] = array("id" => 143, "name" => "NEW CALEDONIA");
		$countries["NL"] = array("id" => 141, "name" => "NETHERLANDS");
		$countries["MR"] = array("id" => 126, "name" => "MAURITANIA");
		$countries["MQ"] = array("id" => 125, "name" => "MARTINIQUE");
		$countries["MH"] = array("id" => 124, "name" => "MARSHALL ISLANDS");
		$countries["MT"] = array("id" => 123, "name" => "MALTA");
		$countries["ML"] = array("id" => 122, "name" => "MALI");
		$countries["MV"] = array("id" => 121, "name" => "MALDIVES");
		$countries["MY"] = array("id" => 120, "name" => "MALAYSIA");
		$countries["MW"] = array("id" => 119, "name" => "MALAWI");
		$countries["MG"] = array("id" => 118, "name" => "MADAGASCAR");
		$countries["MK"] = array("id" => 117, "name" => "MACEDONIA");
		$countries["MO"] = array("id" => 116, "name" => "MACAU");
		$countries["LU"] = array("id" => 115, "name" => "LUXEMBOURG");
		$countries["MU"] = array("id" => 127, "name" => "MAURITIUS");
		$countries["YT"] = array("id" => 128, "name" => "MAYOTTE");
		$countries["NP"] = array("id" => 140, "name" => "NEPAL");
		$countries["NR"] = array("id" => 139, "name" => "NAURU");
		$countries["NA"] = array("id" => 138, "name" => "NAMIBIA");
		$countries["MM"] = array("id" => 137, "name" => "MYANMAR");
		$countries["MZ"] = array("id" => 136, "name" => "MOZAMBIQUE");
		$countries["MA"] = array("id" => 135, "name" => "MOROCCO");
		$countries["MS"] = array("id" => 134, "name" => "MONTSERRAT");
		$countries["MN"] = array("id" => 133, "name" => "MONGOLIA");
		$countries["MC"] = array("id" => 132, "name" => "MONACO");
		$countries["MD"] = array("id" => 131, "name" => "MOLDOVA");
		$countries["FM"] = array("id" => 130, "name" => "MICRONESIA");
		$countries["MX"] = array("id" => 129, "name" => "MEXICO");
		$countries["LT"] = array("id" => 114, "name" => "LITHUANIA");
		$countries["RS"] = array("id" => 227, "name" => "SERBIA");
		$countries["AE"] = array("id" => 211, "name" => "UNITED ARAB EMIRATES");
		$countries["UA"] = array("id" => 210, "name" => "UKRAINE");
		$countries["UG"] = array("id" => 209, "name" => "UGANDA");
		$countries["TV"] = array("id" => 208, "name" => "TUVALU");
		$countries["TC"] = array("id" => 207, "name" => "TURKS AND CAICOS ISLANDS");
		$countries["TM"] = array("id" => 206, "name" => "TURKMENISTAN");
		$countries["TR"] = array("id" => 205, "name" => "TURKEY");
		$countries["TN"] = array("id" => 204, "name" => "TUNISIA");
		$countries["TT"] = array("id" => 203, "name" => "TRINIDAD AND TOBAGO");
		$countries["TO"] = array("id" => 202, "name" => "TONGA");
		$countries["TK"] = array("id" => 201, "name" => "TOKELAU");
		$countries["TG"] = array("id" => 200, "name" => "TOGO");
		$countries["UY"] = array("id" => 212, "name" => "URUGUAY");
		$countries["UZ"] = array("id" => 213, "name" => "UZBEKISTAN");
		$countries["BA"] = array("id" => 226, "name" => "BOSNIA AND HERZEGOVINA");
		$countries["KR"] = array("id" => 225, "name" => "SOUTH KOREA");
		$countries["ZW"] = array("id" => 224, "name" => "ZIMBABWE");
		$countries["ZM"] = array("id" => 223, "name" => "ZAMBIA");
		$countries["YE"] = array("id" => 221, "name" => "YEMEN");
		$countries["EH"] = array("id" => 220, "name" => "WESTERN SAHARA");
		$countries["WF"] = array("id" => 219, "name" => "WALLIS AND FUTUNA");
		$countries["VI"] = array("id" => 218, "name" => "VIRGIN ISLANDS, U.S.");
		$countries["VG"] = array("id" => 217, "name" => "VIRGIN ISLANDS, BRITISH");
		$countries["VN"] = array("id" => 216, "name" => "VIETNAM");
		$countries["VE"] = array("id" => 215, "name" => "VENEZUELA");
		$countries["VU"] = array("id" => 214, "name" => "VANUATU");
		$countries["TH"] = array("id" => 199, "name" => "THAILAND");
		$countries["TZ"] = array("id" => 198, "name" => "TANZANIA");
		$countries["SI"] = array("id" => 183, "name" => "SLOVENIA");
		$countries["SK"] = array("id" => 182, "name" => "SLOVAKIA");
		$countries["SG"] = array("id" => 181, "name" => "SINGAPORE");
		$countries["SL"] = array("id" => 180, "name" => "SIERRA LEONE");
		$countries["SC"] = array("id" => 179, "name" => "SEYCHELLES");
		$countries["SN"] = array("id" => 178, "name" => "SENEGAL");
		$countries["SA"] = array("id" => 177, "name" => "SAUDI ARABIA");
		$countries["ST"] = array("id" => 176, "name" => "SAO TOME AND PRINCIPE");
		$countries["SM"] = array("id" => 175, "name" => "SAN MARINO");
		$countries["WS"] = array("id" => 174, "name" => "SAMOA");
		$countries["VC"] = array("id" => 173, "name" => "SAINT VINCENT");
		$countries["PM"] = array("id" => 172, "name" => "SAINT PIERRE AND MIQUELON");
		$countries["SB"] = array("id" => 184, "name" => "SOLOMON ISLANDS");
		$countries["SO"] = array("id" => 185, "name" => "SOMALIA");
		$countries["TJ"] = array("id" => 197, "name" => "TAJIKISTAN");
		$countries["TW"] = array("id" => 196, "name" => "TAIWAN");
		$countries["SY"] = array("id" => 195, "name" => "SYRIAN ARAB REPUBLIC");
		$countries["CH"] = array("id" => 194, "name" => "SWITZERLAND");
		$countries["SE"] = array("id" => 193, "name" => "SWEDEN");
		$countries["SZ"] = array("id" => 192, "name" => "SWAZILAND");
		$countries["SJ"] = array("id" => 191, "name" => "SVALBARD AND JAN MAYEN");
		$countries["SR"] = array("id" => 190, "name" => "SURINAME");
		$countries["SD"] = array("id" => 189, "name" => "SUDAN");
		$countries["LK"] = array("id" => 188, "name" => "SRI LANKA");
		$countries["ES"] = array("id" => 187, "name" => "SPAIN");
		$countries["ZA"] = array("id" => 186, "name" => "SOUTH AFRICA");
		$countries["LC"] = array("id" => 171, "name" => "SAINT LUCIA");
		$countries["DM"] = array("id" => 57, "name" => "DOMINICA");
		$countries["CL"] = array("id" => 42, "name" => "CHILE");
		$countries["TD"] = array("id" => 41, "name" => "CHAD");
		$countries["KY"] = array("id" => 40, "name" => "CAYMAN ISLANDS");
		$countries["CV"] = array("id" => 39, "name" => "CAPE VERDE");
		$countries["CM"] = array("id" => 38, "name" => "CAMEROON");
		$countries["KH"] = array("id" => 37, "name" => "CAMBODIA");
		$countries["BI"] = array("id" => 36, "name" => "BURUNDI");
		$countries["BF"] = array("id" => 35, "name" => "BURKINA FASO");
		$countries["BG"] = array("id" => 34, "name" => "BULGARIA");
		$countries["BN"] = array("id" => 33, "name" => "BRUNEI DARUSSALAM");
		$countries["BR"] = array("id" => 32, "name" => "BRAZIL");
		$countries["BV"] = array("id" => 31, "name" => "BOUVET ISLAND");
		$countries["CN"] = array("id" => 43, "name" => "CHINA");
		$countries["CX"] = array("id" => 44, "name" => "CHRISTMAS ISLAND");
		$countries["DJ"] = array("id" => 56, "name" => "DJIBOUTI");
		$countries["DK"] = array("id" => 55, "name" => "DENMARK");
		$countries["CZ"] = array("id" => 54, "name" => "CZECH REPUBLIC");
		$countries["CY"] = array("id" => 53, "name" => "CYPRUS");
		$countries["CU"] = array("id" => 52, "name" => "CUBA");
		$countries["HR"] = array("id" => 51, "name" => "CROATIA");
		$countries["CI"] = array("id" => 50, "name" => "COTE D'IVOIRE");
		$countries["CR"] = array("id" => 49, "name" => "COSTA RICA");
		$countries["CK"] = array("id" => 48, "name" => "COOK ISLANDS");
		$countries["CG"] = array("id" => 47, "name" => "CONGO");
		$countries["KM"] = array("id" => 46, "name" => "COMOROS");
		$countries["CO"] = array("id" => 45, "name" => "COLOMBIA");
		$countries["BW"] = array("id" => 30, "name" => "BOTSWANA");
		$countries["BO"] = array("id" => 29, "name" => "BOLIVIA");
		$countries["AM"] = array("id" => 14, "name" => "ARMENIA");
		$countries["AR"] = array("id" => 13, "name" => "ARGENTINA");
		$countries["AG"] = array("id" => 12, "name" => "ANTIGUA AND BARBUDA");
		$countries["AQ"] = array("id" => 11, "name" => "ANTARCTICA");
		$countries["AI"] = array("id" => 10, "name" => "ANGUILLA");
		$countries["AO"] = array("id" => 9, "name" => "ANGOLA");
		$countries["AD"] = array("id" => 8, "name" => "ANDORRA");
		$countries["AS"] = array("id" => 7, "name" => "AMERICAN SAMOA");
		$countries["DZ"] = array("id" => 6, "name" => "ALGERIA");
		$countries["AL"] = array("id" => 5, "name" => "ALBANIA");
		$countries["AF"] = array("id" => 4, "name" => "AFGHANISTAN");
		$countries["GB"] = array("id" => 3, "name" => "UNITED KINGDOM");
		$countries["AW"] = array("id" => 15, "name" => "ARUBA");
		$countries["AU"] = array("id" => 16, "name" => "AUSTRALIA");
		$countries["BT"] = array("id" => 28, "name" => "BHUTAN");
		$countries["BM"] = array("id" => 27, "name" => "BERMUDA");
		$countries["BJ"] = array("id" => 26, "name" => "BENIN");
		$countries["BZ"] = array("id" => 25, "name" => "BELIZE");
		$countries["BE"] = array("id" => 24, "name" => "BELGIUM");
		$countries["BY"] = array("id" => 23, "name" => "BELARUS");
		$countries["BB"] = array("id" => 22, "name" => "BARBADOS");
		$countries["BD"] = array("id" => 21, "name" => "BANGLADESH");
		$countries["BH"] = array("id" => 20, "name" => "BAHRAIN");
		$countries["BS"] = array("id" => 19, "name" => "BAHAMAS");
		$countries["AZ"] = array("id" => 18, "name" => "AZERBAIJAN");
		$countries["AT"] = array("id" => 17, "name" => "AUSTRIA");
		$countries["CA"] = array("id" => 2, "name" => "CANADA");
		$countries["LI"] = array("id" => 113, "name" => "LIECHTENSTEIN");
		$countries["IE"] = array("id" => 98, "name" => "IRELAND");
		$countries["IQ"] = array("id" => 97, "name" => "IRAQ");
		$countries["IR"] = array("id" => 96, "name" => "IRAN");
		$countries["ID"] = array("id" => 95, "name" => "INDONESIA");
		$countries["IN"] = array("id" => 94, "name" => "INDIA");
		$countries["IS"] = array("id" => 93, "name" => "ICELAND");
		$countries["HU"] = array("id" => 92, "name" => "HUNGARY");
		$countries["HK"] = array("id" => 91, "name" => "HONG KONG");
		$countries["HN"] = array("id" => 90, "name" => "HONDURAS");
		$countries["HT"] = array("id" => 89, "name" => "HAITI");
		$countries["GY"] = array("id" => 88, "name" => "GUYANA");
		$countries["GW"] = array("id" => 87, "name" => "GUINEA-BISSAU");
		$countries["IL"] = array("id" => 99, "name" => "ISRAEL");
		$countries["IT"] = array("id" => 100, "name" => "ITALY");
		$countries["LR"] = array("id" => 112, "name" => "LIBERIA");
		$countries["LS"] = array("id" => 111, "name" => "LESOTHO");
		$countries["LB"] = array("id" => 110, "name" => "LEBANON");
		$countries["LV"] = array("id" => 109, "name" => "LATVIA");
		$countries["KG"] = array("id" => 108, "name" => "KYRGYZSTAN");
		$countries["KW"] = array("id" => 107, "name" => "KUWAIT");
		$countries["KI"] = array("id" => 106, "name" => "KIRIBATI");
		$countries["KE"] = array("id" => 105, "name" => "KENYA");
		$countries["KZ"] = array("id" => 104, "name" => "KAZAKSTAN");
		$countries["JO"] = array("id" => 103, "name" => "JORDAN");
		$countries["JP"] = array("id" => 102, "name" => "JAPAN");
		$countries["JM"] = array("id" => 101, "name" => "JAMAICA");
		$countries["GN"] = array("id" => 86, "name" => "GUINEA");
		$countries["GT"] = array("id" => 85, "name" => "GUATEMALA");
		$countries["FI"] = array("id" => 70, "name" => "FINLAND");
		$countries["FJ"] = array("id" => 69, "name" => "FIJI");
		$countries["FO"] = array("id" => 68, "name" => "FAROE ISLANDS");
		$countries["FK"] = array("id" => 67, "name" => "FALKLAND ISLANDS");
		$countries["ET"] = array("id" => 66, "name" => "ETHIOPIA");
		$countries["EE"] = array("id" => 65, "name" => "ESTONIA");
		$countries["ER"] = array("id" => 64, "name" => "ERITREA");
		$countries["GQ"] = array("id" => 63, "name" => "EQUATORIAL GUINEA");
		$countries["SV"] = array("id" => 62, "name" => "EL SALVADOR");
		$countries["EG"] = array("id" => 61, "name" => "EGYPT");
		$countries["EC"] = array("id" => 60, "name" => "ECUADOR");
		$countries["TL"] = array("id" => 59, "name" => "EAST TIMOR");
		$countries["FR"] = array("id" => 71, "name" => "FRANCE");
		$countries["GF"] = array("id" => 72, "name" => "FRENCH GUIANA");
		$countries["GU"] = array("id" => 84, "name" => "GUAM");
		$countries["GP"] = array("id" => 83, "name" => "GUADELOUPE");
		$countries["GD"] = array("id" => 82, "name" => "GRENADA");
		$countries["GL"] = array("id" => 81, "name" => "GREENLAND");
		$countries["GR"] = array("id" => 80, "name" => "GREECE");
		$countries["GI"] = array("id" => 79, "name" => "GIBRALTAR");
		$countries["GH"] = array("id" => 78, "name" => "GHANA");
		$countries["DE"] = array("id" => 77, "name" => "GERMANY");
		$countries["GE"] = array("id" => 76, "name" => "GEORGIA");
		$countries["GM"] = array("id" => 75, "name" => "GAMBIA");
		$countries["GA"] = array("id" => 74, "name" => "GABON");
		$countries["PF"] = array("id" => 73, "name" => "FRENCH POLYNESIA");
		$countries["DO"] = array("id" => 58, "name" => "DOMINICAN REPUBLIC");

		foreach($countries as $iso => $values) {
			echo '<option value="', $values['id'], '" data-iso="', $iso, '">', $values['name'], '</option>', "\n";
		}
	}
}

if (!function_exists('birthdate_day_select'))
{

	/**
	 * 
	 */
	function birthdate_day_select() {

		for($i=1; $i<=31; $i++)
		{
			echo '<option value="', $i, '">', $i, '</option>', "\n";
		}
	}
}

if (!function_exists('birthdate_month_select'))
{

	/**
	 * 
	 */
	function birthdate_month_select() {

		for ($i = 0; $i < 12; $i ++)
		{
			$month_number = sprintf('%02s', $i + 1);
			echo sprintf(
				'<option value="%s" %s>%s</option>',
				$month_number,
				($month_number == $selected ? 'selected="selected"' : ''),
				$month_number);
		}
	}
}

if (!function_exists('birthdate_year_select'))
{

	/**
	 * 
	 */
	function birthdate_year_select() {
		
		$starts = 1920;
		$ends = date("Y");
		for ($i = $ends; $i >= $starts; $i --)
		{
			echo sprintf(
				'<option value="%s">%s</option>',
				$i,
				$i);
		}
	}
}

if (!function_exists('load_recaptcha_script'))
{

	/**
	 * 
	 */
	function load_recaptcha_script() {
		
		echo '<script type="text/javascript" src="//www.google.com/recaptcha/api/js/recaptcha_ajax.js"></script>';
	}
}



// Gabriel Sosa and Magali Ickowicz for FanBridge Inc.
// @pendexgabo
// @maguitai
// 2014