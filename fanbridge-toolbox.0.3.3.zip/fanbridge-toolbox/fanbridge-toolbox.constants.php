<?php

// plugin name
define('FBTB_PLUGIN_NAME', untrailingslashit(basename(dirname(__FILE__))));

// plugin version
define('FBTB_PLUGIN_VERSION', '0.3.3');

// plugin url
define('FBTB_PLUGIN_URL', trailingslashit(WP_PLUGIN_URL) . trailingslashit(FBTB_PLUGIN_NAME));

// plugin abs path
define('FBTB_PLUGIN_PATH', trailingslashit(WP_PLUGIN_DIR) . trailingslashit(FBTB_PLUGIN_NAME));

// users grants
define('FBTB_PLUGIN_GRANTS', 'manage_options');

// fanbridge urls
define('FBTB_SITE_URL', 'www.fanbridge.com');
define('FBTB_API_URL', 'http://api.fanbridge.com');
define('FBTB_API_SCHEMA', 'http://');
define('FBTB_SUBSCRIBE_ENDPOINT', '//' . FBTB_SITE_URL . '/signup/1.5/submit');

// fanbridge api settings
define('FBTB_API_KEY', '4b7431b2429c4dc780b6224984fa9fb5');
define('FBTB_SN_API_TOKEN', 'api_token');
define('FBTB_SN_API_SECRET', 'api_secret');
define('FBTB_SN_API_USER_ID', 'user_id');

// general settings
define('FBTB_PREFIX', 'fbridge_tb_');
define('FBTB_CACHING_TIME', 86400);

define('FBTB_CACHED_TIME', 'cached_time');
define('FBTB_FAN_QUESTIONS', 'fan_questions');
define('FBTB_EVENTS', 'events');
define('FBTB_FQ_WIDGET_ID', 'fq_widget_id');
define('FBTB_EVENTS_WIDGET_ID', 'events_widget_id');

// signup form settings
define('FBTB_SN_EMAIL', 'email');
define('FBTB_SN_USER_ID', 'userid');
define('FBTB_SN_FORM_TITLE', 'form_title');
define('FBTB_SN_FIRST_NAME', 'firstname');
define('FBTB_SN_LAST_NAME', 'lastname');
define('FBTB_SN_ZIP_CODE', 'zip');
define('FBTB_SN_COUNTRY', 'country');
define('FBTB_SN_STATE', 'state');
define('FBTB_SN_CITY', 'city');
define('FBTB_SN_GROUP', 'group_id');
define('FBTB_SN_GEOIP', 'sn_geoip');
define('FBTB_SN_CUSTOM_COLORS', 'sn_custom_color');
define('FBTB_SN_HIGHLIGHT_COLOR', 'sn_highlight_color');
define('FBTB_SN_BIRTHDATE', 'birthdate');
define('FBTB_SN_BIRTHDATE_DAY', 'birth_day');
define('FBTB_SN_BIRTHDATE_MONTH', 'birth_month');
define('FBTB_SN_BIRTHDATE_YEAR', 'birth_year');
define('FBTB_SN_COPPA_COMPLIANT', 'coppa_compliant');
define('FBTB_SN_COPPA_COMPLIANT_AGE', 13);
define('FBTB_SN_CAPTCHA_DIV', 'recaptcha_div');

define('FB_RECAPTCHA_PUBLIC_KEY', '6LcD9-gSAAAAANTwDR8dtFvPKHQ1bN-vy63oNR3W');





// Gabriel Sosa and Magali Ickowicz for FanBridge Inc.
// @pendexgabo
// @maguitai
// 2014