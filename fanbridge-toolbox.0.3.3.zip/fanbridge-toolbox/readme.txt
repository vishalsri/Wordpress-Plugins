=== FanBridge toolbox ===
Contributors: fanbridge, pendexgabo, maguitai
Tags: fanbridge, fans, email, newsletter, signup, marketing, plugin, widget
Requires at least: 3.0
Tested up to: 3.9
Stable tag: 0.3.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The FanBridge Toolbox plugin allows you to add an email signup form, an events widget and a fan questions widget to your Wordpress blog

== Description ==

The FanBridge Toolbox plugin allows you to add an email signup form to your Wordpress blog. The form automatically adds signups to your FanBridge account. Additionally you can add an events widget to show your upcoming events and a Fan Questions widget to allow your subscribers to ask you questions directly from within your Wordpress.

Not using FanBridge? [Learn more](http://www.fanbridge.com/tour/?utm_source=wordpress&utm_medium=plugin_description&utm_campaign=plugin&ref=wordpress_plugin_description) about how FanBridge helps you grow, engage, and monetize your fan base.

After installing the FanBridge Toolbox plugin, you'll be able to login to your FanBridge account. After logging in you will get the list of the widgets that you have created at FanBridge and choose which one you want to add to your blog. You will also be able to customize your signup form.
Setup takes less than 5 minutes and doesn't require any file editing. Download, customize, and get more fans!

== Installation ==

This section describes how to install the plugin and get it working.

1. Unzip and upload the entire `fanbridge-toolbox` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Settings and look for "FanBridge Toolbox" in the menu
4. Connect yout account.
5. Go to "Fan Acquisition" tab
6. Customize your signup form with additional appearance and data field options
7. Go to "Fan Questions" tab
8. Choose the Fan Questions widget you want to add to your blog
9. Go to "Events" tab
10. Choose the Events widget you want to add to your blog
11. Go to Appearance->Widgets and drag the `FanBridge Signup Widget`, `FanBridge FanQuestions Widget` and `FanBridge events Widget` widgets into the area that you want.
12. Enjoy!

== Frequently Asked Questions ==

= What is FanBridge? =

[FanBridge](http://www.fanbridge.com/?utm_source=wordpress&utm_medium=plugin_description&utm_campaign=plugin&ref=wordpress_plugin_description) is the leading Fan Relationship Management platform. We help entertainers, brands, and small businesses grow, engage, and monetize their fan bases through email and social media. Currently, we have over 120 million fans under management.

Want to know exactly what FanBridge can do for you? [Visit our site](http://www.fanbridge.com/?utm_source=wordpress&utm_medium=plugin_description&utm_campaign=plugin&ref=wordpress_plugin_description).

= Is it free? =

We offer a free trial that you can learn about [here](http://www.fanbridge.com/plan/?utm_source=wordpress&utm_medium=plugin_description&utm_campaign=plugin&ref=wordpress_plugin_description). 

== Screenshots ==

1. Connect with your FanBridge account
2. Customizing your signup form with additional appearance, data field options and groups selection.
3. Selecting the Fan Questions widget
4. Selecting the Events widget
5. Adding the widgets into one of your Widget Areas
6. An example of the FanBridge Signup widget
7. An example of the FanBridge Fan Questions widget
8. An example of the FanBridge Events widget

== Changelog ==

= 0.3.2 =
* Fixed cross SSL issue

= 0.3.1 =
* Performance enhancement

= 0.3 =
* Added recaptcha

= 0.2 =
* Added COPPA compliance

= 0.1 =
* Initial release

== Upgrade Notice ==



