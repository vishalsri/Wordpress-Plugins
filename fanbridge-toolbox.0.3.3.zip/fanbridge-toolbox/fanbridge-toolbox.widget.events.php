<?php

/**
 * set the parameters of our plugin to the system
 * 
 * @return void
 */
class FanBridge_ToolBox_Widget_Events extends WP_Widget {

	public function FanBridge_ToolBox_Widget_Events() {
		$widget_ops = array( 
			'description' => 'Adds a FanBridge signup form to your blog'
		);
		$this->WP_Widget('FanBridge_ToolBox_Widget_Events', 'FanBridge events Widget', $widget_ops);
	}

	public function widget( $args, $instance) {
		if (!is_array($instance)) {
			$instance = array();
		}

		$args['widget_type'] = 'events';
		echo fbridge_tb_display_widget(array_merge($args, $instance));
		
	}

	public function form( $instance ) {

	}

	public function update( $new_instance, $old_instance) {
		
	}
}


// Gabriel Sosa and Magali Ickowicz for FanBridge Inc.
// @pendexgabo
// @maguitai
// 2014