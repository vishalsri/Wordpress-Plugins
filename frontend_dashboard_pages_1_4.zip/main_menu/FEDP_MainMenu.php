<?php
if ( ! class_exists( 'FEDP_MainMenu' ) ) {
	class FEDP_MainMenu {
		public function __construct() {
			add_action( 'fed_add_main_menu_item_bottom', array( $this, 'fed_pages_add_main_menu_item_bottom' ) );
			add_action( 'fed_edit_main_menu_item_bottom', array( $this, 'fed_pages_edit_main_menu_item_bottom' ) );
			add_action( 'fed_enqueue_script_style_admin', array( $this, 'fed_pages_enqueue_script_style_admin' ) );
			add_action( 'fed_override_default_page', array( $this, 'fed_pages_override_default_page' ), 10, 2 );
			add_filter( 'fed_process_menu', array( $this, 'fed_pages_process_menu' ), 10, 2 );

			add_filter( 'fed_menu_title', array( $this, 'fed_pages_menu_title' ), 10, 3 );
			add_filter( 'fed_menu_default_page', array( $this, 'fed_pages_menu_default_page' ), 10, 3 );

		}

		public function fed_pages_override_default_page( $menus, $index ) {
			if ( $menus[ $index ]['menu_key'] === 'yes' ) {
				$post = get_post( $menus[ $index ]['menu_value'] );
				$output = '';
				/**
				 * WPBakery Page Custom Page CSS
				 */
				$wpb  = get_post_meta( $post->ID, '_wpb_shortcodes_custom_css', true );
				if ( $wpb ) {
					$shortcodes_custom_css = strip_tags( $wpb );
					$output                = '<style type="text/css" data-type="vc_shortcodes-custom-css">';
					$output                .= $shortcodes_custom_css;
					$output                .= '</style>';
				}

				if ( $post instanceof WP_Post ) {
					echo apply_filters( 'the_content', $post->post_content );
					echo $output;
				}
			}
		}

		public function fed_pages_menu_default_page( $status, $menus, $index ) {
			if ( isset( $menus[ $index ]['menu_key'] ) && $menus[ $index ]['menu_key'] === 'yes' ) {
				return false;
			}

			return $status;
		}

		public function fed_pages_menu_title( $menu_title, $menus, $index ) {
			if ( isset( $menus[ $index ]['menu_key'] ) && $menus[ $index ]['menu_key'] === 'yes' ) {
				$post = get_post( $menus[ $index ]['menu_value'] );
				if ( $post instanceof WP_Post ) {
					$menu_value   = $post->post_title;
					$menu_content = $post->post_content;

					return $menu_value;
				}
			}

			return $menu_title;
		}

		public function fed_pages_add_main_menu_item_bottom() {
			?>
			<div class="row padd_top_20">
				<div class="col-md-7">
					<div class="flex_between fed_pages_menu_item_container">
						<div class="fed_page_menu_checkbox">
							<?php echo fed_get_input_details( array(
								'input_meta'    => 'fed_menu_key',
								'input_type'    => 'checkbox',
								'default_value' => 'yes',
								'user_value'    => '',
								'class_name'    => 'fed_show_pages_checkbox',
								'label'         => 'Show pages for this menu item?'
							) ) ?>
						</div>
						<div class="fed_page_menu_pages hide">
							<?php wp_dropdown_pages( array( 'name' => 'fed_menu_value' ) ) ?>
						</div>
					</div>
				</div>
			</div>

			<?php
		}

		public function fed_pages_edit_main_menu_item_bottom( $menu ) {
			$hide = isset( $menu['menu_key'] ) && $menu['menu_key'] === 'yes' ? '' : 'hide';
			if ( $menu['extra'] !== 'no' ) {
				?>
				<div class="row padd_top_20">
					<div class="col-md-7">
						<div class="flex_between fed_pages_menu_item_container">
							<div class="fed_page_menu_checkbox">
								<?php echo fed_get_input_details( array(
									'input_meta'    => 'fed_menu_key',
									'input_type'    => 'checkbox',
									'default_value' => 'yes',
									'user_value'    => isset( $menu['menu_key'] ) ? $menu['menu_key'] : '',
									'class_name'    => 'fed_show_pages_checkbox',
									'label'         => 'Show pages for this menu item?',

								) ) ?>
							</div>
							<div class="fed_page_menu_pages <?php echo $hide ?>">
								<?php wp_dropdown_pages( array(
									'name'     => 'fed_menu_value',
									'selected' => isset( $menu['menu_value'] ) ? $menu['menu_value'] : ''
								) ) ?>
							</div>
						</div>
					</div>
				</div>
				<?php
			}
		}

		public function fed_pages_process_menu( $default_value, $row ) {
			$new_value = array(
				'menu_key'   => isset( $row['fed_menu_key'] ) ? esc_attr( $row['fed_menu_key'] ) : null,
				'menu_value' => isset( $row['fed_menu_value'] ) ? esc_attr( $row['fed_menu_value'] ) : null
			);

			return array_merge( $default_value, $new_value );
		}

		public function fed_pages_enqueue_script_style_admin() {
			wp_enqueue_script( 'fed_pages_script', plugins_url( '/assets/fed_script_pages.js', FED_PAGES_PLUGIN ), array() );
		}
	}

	new FEDP_MainMenu();
}