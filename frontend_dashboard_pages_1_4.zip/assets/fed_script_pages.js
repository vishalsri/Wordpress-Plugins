jQuery(document).ready(function ($) {
        var b = $('.bc_fed');
        b.on('change', 'input[name=fed_menu_key]', function (e) {
            var click = $(this);
            var closest = click.closest('.fed_pages_menu_item_container');
            if (closest.find('.fed_page_menu_pages').hasClass('hide')) {
                closest.find('.fed_page_menu_pages').removeClass('hide');
            } else {
                closest.find('.fed_page_menu_pages').addClass('hide');
            }
        });

    }
);
