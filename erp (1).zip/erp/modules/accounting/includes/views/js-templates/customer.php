<input type="hidden" name="type" value="customer">
<input type="hidden" name="field_id" value="0">
<?php
$item_type = 'customer';
include dirname( dirname( __FILE__ ) ) . '/user-form-rows.php'; 
?>
