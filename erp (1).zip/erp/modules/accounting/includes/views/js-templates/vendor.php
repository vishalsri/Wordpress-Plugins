<input type="hidden" name="type" value="vendor">
<input type="hidden" name="field_id" value="0">
<?php 
$item_type = 'vendor';
include dirname( dirname( __FILE__ ) ) . '/user-form-rows.php'; 
?>