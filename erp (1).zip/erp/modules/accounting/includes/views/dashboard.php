<div class="wrap erp accounting-dashboard">
    <h2><?php _e( 'Accounting', 'erp' ); ?></h2>

    <div class="erp-single-container">

        <div class="erp-area-left">

            <?php do_action( 'erp_ac_dashboard_widgets_left' ); ?>

        </div><!-- .erp-area-left -->

        <div class="erp-area-right">

            <?php do_action( 'erp_ac_dashboard_widgets_right' ); ?>

        </div>

    </div>
</div>
