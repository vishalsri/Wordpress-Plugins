<?php

namespace Stripe;

class AlipayAccount extends ExternalAccount
{

}
