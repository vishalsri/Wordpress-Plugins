<div class="ihc-popup-wrapp" id="popup_box">
	<div class="ihc-the-popup">
        <div class="ihc-popup-top">
        	<div class="title">Membership Pro Ultimate Wp</div>
            <div class="close-bttn" onClick="ihc_closePopup();"></div>
            <div class="clear"></div>
        </div>
        <div class="ihc-popup-content" style="text-align: center;">
        	<div style="margin: 0 auto; display: inline-block;">
	            <div class="ihc-popup-shortcodevalue" onClick="tinymce.execCommand('ihc_return_text', '[ihc-register]');"><i class="fa-ihc fa-user-plus-ihc"></i><?php _e('Register Form', 'ihc');?></div>
	            <div class="ihc-popup-shortcodevalue" onClick="tinymce.execCommand('ihc_return_text', '[ihc-login-form]');"><i class="fa-ihc fa-sign-in-ihc"></i><?php _e('Login Form', 'ihc');?></div>
	            <div class="ihc-popup-shortcodevalue" onClick="tinymce.execCommand('ihc_return_text', '[ihc-logout-link]');"><i class="fa-ihc fa-sign-out-ihc"></i><?php _e('Logout Button', 'ihc');?></div>
	            <div class="ihc-popup-shortcodevalue" onClick="tinymce.execCommand('ihc_return_text', '[ihc-pass-reset]');"><i class="fa-ihc fa-unlock-ihc"></i><?php _e('Password Recovery', 'ihc');?></div>
	            <div class="ihc-popup-shortcodevalue" onClick="tinymce.execCommand('ihc_return_text', '[ihc-user-page]');"><i class="fa-ihc fa-user-ihc"></i><?php _e('User Page', 'ihc');?></div>
	            <div class="ihc-popup-shortcodevalue" onClick="tinymce.execCommand('ihc_return_text', '[ihc-select-level]');"><i class="fa-ihc fa-user-plus-ihc"></i><?php _e('Subscription Plan', 'ihc');?></div>	            
				<div class="ihc-popup-shortcodevalue" onClick="tinymce.execCommand('ihc_return_text', '[ihc-visitor-inside-user-page]');"><i class="fa-ihc fa-user-ihc"></i><?php _e('Visitor Inside User Page', 'ihc');?></div>
				<div class="ihc-clear"></div>
        	</div>
    	</div>
    </div>
</div>