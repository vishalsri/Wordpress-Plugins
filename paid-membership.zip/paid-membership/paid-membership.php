<?php
/*
Plugin Name: Paid Membership and Content
Plugin URI: http://www.videochat-scripts.com/
Description: Paid Membership and Content: Sell membership and content based on virtual wallet credits/tokens. Credits/tokens can be purchased with real money.
Version: 1.3.4
Author: VideoWhisper.com
Author URI: http://www.videowhisper.com/
Contributors: videowhisper, VideoWhisper.com
*/

if (!class_exists("VWpaidMembership"))
{
	class VWpaidMembership {

		function VWpaidMembership() { //constructor

		}

		//! Plugin Hooks
		function init()
		{

		}

		function activation()
		{
			wp_schedule_event(time(), 'daily', 'cron_membership_update');
		}

		function deactivation()
		{
			wp_clear_scheduled_hook('cron_membership_update');
		}

		function plugins_loaded()
		{
			//settings link in plugins view
			$plugin = plugin_basename(__FILE__);
			add_filter("plugin_action_links_$plugin",  array('VWpaidMembership','settings_link') );

			$options = get_option('VWpaidMembershipOptions');

			//shortcodes
			add_shortcode('videowhisper_membership_buy', array( 'VWpaidMembership', 'videowhisper_membership_buy'));

			add_shortcode('videowhisper_content_edit', array( 'VWpaidMembership', 'videowhisper_content_edit'));
		}

		//! Feature Pages and Menus
		function setupPages()
		{
			$options = get_option('VWpaidMembershipOptions');
			if ($options['disableSetupPages']) return;

			//menu pages
			$pages = array(
				'videowhisper_membership_buy' => 'Membership',
				'mycred_buy_form' => 'Buy Credits',
			);

			//create a menu and add pages
			$menu_name = 'VideoWhisper';
			$menu_exists = wp_get_nav_menu_object( $menu_name );

			if (!$menu_exists) $menu_id = wp_create_nav_menu($menu_name);
			else $menu_id = $menu_exists->term_id;


			//create pages if not created or existant
			foreach ($pages as $key => $value)
			{
				$pid = $options['p_'.$key];
				$page = get_post($pid);
				if (!$page) $pid = 0;

				if (!$pid)
				{
					global $user_ID;
					$page = array();
					$page['post_type']    = 'page';
					$page['post_content'] = '['.$key.']';
					$page['post_parent']  = 0;
					$page['post_author']  = $user_ID;
					$page['post_status']  = 'publish';
					$page['post_title']   = $value;
					$page['comment_status'] = 'closed';

					$pid = wp_insert_post ($page);

					$options['p_'.$key] = $pid;
					$link = get_permalink( $pid);

					if ($menu_id) wp_update_nav_menu_item($menu_id, 0, array(
								'menu-item-title' =>  $value,
								'menu-item-url' => $link,
								'menu-item-status' => 'publish'));

				}

			}

			//just pages (system use)

			$pages = array(
				'videowhisper_content_edit' => 'Edit Content',
			);

			foreach ($pages as $key => $value)
			{
				$pid = $options['p_'.$key];
				$page = get_post($pid);
				if (!$page) $pid = 0;

				if (!$pid)
				{
					global $user_ID;
					$page = array();
					$page['post_type']    = 'page';
					$page['post_content'] = '['.$key.']';
					$page['post_parent']  = 0;
					$page['post_author']  = $user_ID;
					$page['post_status']  = 'publish';
					$page['post_title']   = $value;
					$page['comment_status'] = 'closed';

					$pid = wp_insert_post ($page);

					$options['p_'.$key] = $pid;
				}

			}

			update_option('VWpaidMembershipOptions', $options);
		}

		function get_current_user_role() {
			global $wp_roles;
			$current_user = wp_get_current_user();
			$roles = $current_user->roles;
			$role = array_shift($roles);
			return isset($wp_roles->role_names[$role]) ? translate_user_role($wp_roles->role_names[$role] ) : false;
		}

		function getCurrentURL()
		{
			$currentURL = (@$_SERVER["HTTPS"] == "on") ? "https://" : "http://";
			$currentURL .= $_SERVER["SERVER_NAME"];

			if($_SERVER["SERVER_PORT"] != "80" && $_SERVER["SERVER_PORT"] != "443")
			{
				$currentURL .= ":".$_SERVER["SERVER_PORT"];
			}

			$uri_parts = explode('?', $_SERVER['REQUEST_URI'], 2);

			$currentURL .= $uri_parts[0];
			return $currentURL;
		}


		function path2url($file, $Protocol='http://')
		{
			if (is_ssl() && $Protocol=='http://') $Protocol='https://';

			$url = $Protocol.$_SERVER['HTTP_HOST'];

			//on godaddy hosting uploads is in different folder like /var/www/clients/ ..
			$upload_dir = wp_upload_dir();
			if (strstr($file, $upload_dir['basedir']))
				return  $upload_dir['baseurl'] . str_replace($upload_dir['basedir'], '', $file);

			//folder under WP path
			require_once(ABSPATH . 'wp-admin/includes/file.php');
			if (strstr($file, get_home_path()))
				return get_home_url() . str_replace(get_home_path(), '/', $file);

			if (strstr($file, $_SERVER['DOCUMENT_ROOT']))
				return  $url . str_replace($_SERVER['DOCUMENT_ROOT'], '', $file);

			return $url . $file;
		}

		//! Shortcodes

		function videowhisper_content_edit($atts)
		{
			$options = get_option('VWpaidMembershipOptions');

			//checks
			if (!is_user_logged_in()) return 'Only registered users can edit their content!';

			$postID = (int) $_GET['editID'];
			$saveID = (int) $_POST['saveID'];

			if (!$postID) $postID = $saveID;
			if (!$postID) return 'This is a system page for editing content, called from other sections. Content ID is required!';

			$post = get_post($postID);
			if (!$post) return 'Content not found!';

			$current_user = wp_get_current_user();

			if ($post->post_author != $current_user->ID && !in_array('administrator', $current_user->roles))
				return 'Only owner and administrator can edit content!';

			//everything fine: edit

			$myCred = 1;

			//mycred
			if ($myCred)
			{
				if ($saveID)
				{
					$mCa = array(
						'status'       => 'enabled',
						'price'        => round($_POST['price'],2),
						'button_label' => 'Buy Now', // default button label
						'expire'       => (int) $_POST['duration'],
						'recurring'    => 0
					);

					update_post_meta( $postID, 'myCRED_sell_content', $mCa );
				}

				$mCa = get_post_meta( $postID, 'myCRED_sell_content', true );
				if ($mCa)
				{
					$oldPrice = $mCa['price'];
					$oldDuration = $mCa['expire'];
				}
			}

			$htmlCode = '<H4>Editing: '.$post->post_title.'</H4>';
			if ($saveID) $htmlCode .= 'Content was updated:';

			$this_page    =  VWpaidMembership::getCurrentURL();

			$htmlCode .=  '<form method="post" enctype="multipart/form-data" action="' . $this_page .'"  name="adminForm">';

			$htmlCode .=  '<h5>Sell Price</h5>
			<input name="price" type="text" id="price" value="'.$oldPrice.'" size="6" maxlength="6" />
			<br>Users need to pay this price to access. Set 0 for free access.';

			$htmlCode .=  '<h5>Access Duration</h5>
			<input name="duration" type="text" id="duration" value="'.$oldDuration.'" size="6" maxlength="6" /> hours.
			<br>Set 720 for 30 days, 0 for unlimited time access (one time flat fee).';

			$htmlCode .=  '<input name="saveID" type="hidden" id="saveID" value="'.$postID.'" />';

			$htmlCode .=  '<p><input class="button videowhisperButton" type="submit" name="save" id="save" value="Save" /></p>
			</form>';

			$htmlCode .= '<a class="button" href="'.get_permalink($postID).'">View Content</A>';

			$post_thumbnail_id = get_post_thumbnail_id($postID);
			if ($postID) $post_featured_image = wp_get_attachment_image_src($post_thumbnail_id, 'featured_preview') ;

					if ($post_featured_image)
					{
						//correct url

						$upload_dir = wp_upload_dir();
						$uploads_url = VWpaidMembership::path2url($upload_dir['basedir']);

						$iurl = $post_featured_image[0];
						$relPath = substr($iurl,strlen($uploads_url));

						if (file_exists($relPath)) $rurl = VWpaidMembership::path2url($relPath);
						else $rurl = $iurl;

				$htmlCode .= '<IMG style="padding-bottom: 20px; padding-right:20px" SRC ="'.$rurl.'" WIDTH="'.$post_featured_image[1].'" HEIGHT="'.$post_featured_image[2].'" ALIGN="LEFT">';
			}

			return $htmlCode;


		}

		function videowhisper_membership_buy($atts)
		{

			$options = get_option('VWpaidMembershipOptions');

			if (!is_user_logged_in()) return stripslashes($options['loginMessage']);

			$user_ID = get_current_user_id();

			$memberships = $options['memberships'];

			//setup membership
			if (isset($_POST['membership_id']))
			{
				$membership_id = (int) $_POST['membership_id'];
				if ($memberships[$membership_id])
				{
					$membership = $memberships[$membership_id];

					if (!VWpaidMembership::membership_setup($membership, $user_ID)) $htmlCode .= '<h4>Error: Your balance does not cover this membership!</h4>';
					else $htmlCode .= '<h4>Membership was activated: ' . $membership['label'] . '</h4>';
				}
			}

			//cancel current membership
			if ($_GET['cancel_membership']=='1')
			{
				VWpaidMembership::membership_cancel($user_ID);
				$htmlCode .= '<h4>Membership was cancelled: automated renewal will no longer occur!</h4>';
			}

			global $wp;
			$current_url = add_query_arg( $wp->query_string, '', home_url( $wp->request ) );


			//current user membership
			$memInfo = VWpaidMembership::membership_info($user_ID);
			if ($memInfo) $htmlCode .= 'Current Membership: ' . $memInfo;

			$membership = get_user_meta($user_ID, 'vw_paid_membership', true);
			if ($membership) if ($membership['recurring'])
				{
					$htmlCode .= '<BR><a href="' . add_query_arg('cancel_membership','1',$current_url) . '" class="button">Cancel Automated Renewal</a><BR>';
				}

			$htmlCode .= '<BR>Current Role: '. VWpaidMembership::get_current_user_role();
			$htmlCode .= '<BR>Current Balance: '.  VWpaidMembership::balance($user_ID);



			if (count($memberships))
			{
				$htmlCode .= '<BR><h4>Select Your Membership</h4>';
				if (!is_array($memberships)) $htmlCode .= 'No memberships defined, yet!';
				else
					foreach ($memberships as $i => $membership)
					{
						$htmlCode .= '<form class="paid_membership_listing" action="' .$current_url. '" method="post">';
						$htmlCode .= '<h4>' . $membership['label'] . '</h4>';
						$htmlCode .= 'Role: ' . $membership['role'];
						$htmlCode .= '<br>Duration: ' . $membership['expire'] . ' days';
						$htmlCode .= '<br>' . ($membership['recurring']?'Automated Renewal':'One Time');
						$htmlCode .= '<br>Price: ' . $membership['price'];
						$htmlCode .= '<input id="membership_id" name="membership_id" type="hidden" value="' . $i. '">';
						$htmlCode .= '<br><input id="submit" name="submit" type="submit" value="Buy Now">';
						$htmlCode .= '</form>';
					}


				$htmlCode .= html_entity_decode(stripslashes($options['customCSS']));


			}
			else echo 'No memberships were setup from backend.';


			return $htmlCode;
		}

		function membership_info($user_ID)
		{
			$membership = get_user_meta($user_ID, 'vw_paid_membership', true);
			if (!$membership) return ;


			$htmlCode .= '<B>'.$membership['label'].'</B> : ';
			$htmlCode .= ' ' . $membership['role'];
			$htmlCode .= ', ' . $membership['expire'] . ' days';
			$htmlCode .= ' until ' . date('M j G:i:s T Y', $membership['expires']) . '';
			$htmlCode .= ', ' . ($membership['recurring']?'recurring':'no renew');

			return $htmlCode ;
		}

		//! Membership Processing

		function membership_update_all()
		{
			$users = get_users(array(
					'meta_key'     => 'vw_paid_membership',
					'fields' => 'ID'
				));

			foreach ( $users as $user ) VWpaidMembership::membership_update($user);
		}

		//update membership: process recurring / end
		function membership_update( $user_ID)
		{
			$membership = get_user_meta($user_ID, 'vw_paid_membership', true);

			if ($membership['expires']> time()) return 0; //still valid

			//end if not recurring
			if (!$membership['recurring'])
			{
				VWpaidMembership::membership_end($user_ID);
				return 0;
			}

			//recurr
			if (VWpaidMembership::membership_apply($membership, $user_ID))
			{
				$membershipCurrent['lastCharge'] = time();
				$membershipCurrent['expires'] = time() + ($membership['expire'] * 86400);

				update_user_meta( $user_ID, 'vw_paid_membership', $membership);

				return 1;
			}
			else
			{
				VWpaidMembership::membership_end($user_ID);
				return 0;
			}
		}

		function membership_end($user_ID)
		{
			$options = get_option('VWpaidMembershipOptions');
			if (!$options['freeRole']) return;

			//create role if missing
			if (!get_role($options['freeRole'])) add_role($options['freeRole'], ucwords($options['freeRole']), array('read' => true) );

			$user_ID = wp_update_user( array( 'ID' => $user_ID, 'role' => $options['freeRole'] ) );

			delete_user_meta( $user_ID, 'vw_paid_membership');
		}

		function membership_cancel($user_ID)
		{
			$membership = get_user_meta($user_ID, 'vw_paid_membership', true);

			if (!$membership) return;
			if (!$membership['recurring']) return;

			$membership['recurring'] = 0;
			update_user_meta( $user_ID, 'vw_paid_membership', $membership);
		}

		function membership_setup($membership, $user_ID)
		{
			if (VWpaidMembership::membership_apply($membership, $user_ID))
			{
				$membership['firstCharge'] = time();
				$membership['lastCharge'] = time();
				$membership['expires'] = time() + ($membership['expire'] * 86400);

				update_user_meta( $user_ID, 'vw_paid_membership', $membership);

				return 1;
			} else return 0;
		}


		function membership_apply($membership, $user_ID)
		{
			$balance = VWpaidMembership::balance($user_ID);
			if ($membership['price']>$balance) return 0;

			//create role if missing
			if (!get_role($membership['role'])) add_role($membership['role'], ucwords($membership['role']), array('read' => true) );

			$user_ID = wp_update_user( array( 'ID' => $user_ID, 'role' => $membership['role'] ) );

			VWpaidMembership::transaction( "paid_membership", $user_ID, - $membership['price'], $membership['label'] . "- Paid Membership Fee.", null, $membership);
			return 1;
		}

		//! Billing Integration

		function balance($userID)
		{
			//get current user balance

			if (!$userID) return 0;

			if (function_exists( 'mycred_get_users_cred')) return mycred_get_users_cred($userID);

			return 0;
		}

		function transaction($ref = "paid_membership", $user_id = 1, $amount = 0, $entry = "Paid Membership Transaction.", $ref_id = null, $data = null)
		{
			//ref = explanation ex. ppv_client_payment
			//entry = explanation ex. PPV client payment in room.
			//utils: ref_id (int|string|array) , data (int|string|array|object)

			if ($amount == 0) return; //nothing

			if ($amount>0)
			{
				if (function_exists('mycred_add')) mycred_add($ref, $user_id, $amount, $entry, $ref_id, $data);
			}
			else
			{
				if (function_exists('mycred_subtract')) mycred_subtract( $ref, $user_id, $amount, $entry, $ref_id, $data );
			}
		}

		//! Admin Side

		function admin_menu() {

			add_menu_page('Paid Membership', 'Paid Membership', 'manage_options', 'paid-membership', array('VWpaidMembership', 'adminOptions'), 'dashicons-awards',83);

			add_submenu_page("paid-membership", "Paid Membership", "Settings", 'manage_options', "paid-membership", array('VWpaidMembership', 'adminOptions'));
			add_submenu_page("paid-membership", "Paid Membership", "Documentation", 'manage_options', "paid-membership-doc", array('VWpaidMembership', 'adminDocs'));

		}

		function settings_link($links) {
			$settings_link = '<a href="admin.php?page=paid-membership">'.__("Settings").'</a>';
			array_unshift($links, $settings_link);
			return $links;
		}

		function adminDocs()
		{
?>
<div class="wrap">
<div id="icon-options-general" class="icon32"><br></div>
<h2>Paid Membership by VideoWhisper</h2>
</div>
<h3>Shortcodes</h3>
<h4>[videowhisper_membership_buy]</h4>
Shows membership info and upgrade options for user.

<?php
		}
		//! Options

		function adminOptionsDefault()
		{

			$upload_dir = wp_upload_dir();
			$root_url = plugins_url();
			$root_ajax = admin_url( 'admin-ajax.php?action=vmls&task=');

			return array(
				'freeRole' => 'Subscriber',
				'memberships' => 'a:3:{i:0;a:5:{s:5:"label";s:5:"Basic";s:4:"role";s:5:"Basic";s:5:"price";s:2:"10";s:6:"expire";s:2:"30";s:9:"recurring";s:1:"1";}i:1;a:5:{s:5:"label";s:8:"Standard";s:4:"role";s:8:"Standard";s:5:"price";s:2:"10";s:6:"expire";s:2:"30";s:9:"recurring";s:1:"1";}i:2;a:5:{s:5:"label";s:7:"Premium";s:4:"role";s:7:"Premium";s:5:"price";s:2:"12";s:6:"expire";s:2:"30";s:9:"recurring";s:1:"1";}}',
				'disableSetupPages' => '0',
				'paid_handler' => 'videowhisper',
				'loginMessage' => 'Upgrading membership is only available for existing users. Please <a href="/wp-login.php?action=register">register</a> or login!',
				'customCSS' => '<style type="text/css">
<!--
.paid_membership_listing
{
padding: 5px;
margin: 5px;
border: solid 1px #AAA;
}
-->
</style>'
			);


		}

		function getAdminOptions() {

			$adminOptions = VWpaidMembership::adminOptionsDefault();

			$options = get_option('VWpaidMembershipOptions');
			if (!empty($options)) {
				foreach ($options as $key => $option)
					$adminOptions[$key] = $option;
			}

			update_option('VWpaidMembershipOptions', $adminOptions);
			return $adminOptions;
		}

		function adminOptions()
		{
			$options = VWpaidMembership::getAdminOptions();
			$optionsDefault = VWpaidMembership::adminOptionsDefault();

			if (isset($_POST))
			{
				foreach ($options as $key => $value)
					if (isset($_POST[$key])) $options[$key] = $_POST[$key];
					update_option('VWpaidMembershipOptions', $options);
			}

			VWpaidMembership::setupPages();

			$active_tab = isset( $_GET[ 'tab' ] ) ? $_GET[ 'tab' ] : 'settings';

?>
<div class="wrap">
<div id="icon-options-general" class="icon32"><br></div>
<h2>Paid Membership by VideoWhisper</h2>
</div>

<h2 class="nav-tab-wrapper">
	<a href="admin.php?page=paid-membership&tab=settings" class="nav-tab <?php echo $active_tab=='settings'?'nav-tab-active':'';?>">General Settings</a>
	<a href="admin.php?page=paid-membership&tab=membership" class="nav-tab <?php echo $active_tab=='membership'?'nav-tab-active':'';?>">Membership Levels</a>
	<a href="admin.php?page=paid-membership&tab=billing" class="nav-tab <?php echo $active_tab=='billing'?'nav-tab-active':'';?>">Billing</a>
	<a href="admin.php?page=paid-membership&tab=users" class="nav-tab <?php echo $active_tab=='users'?'nav-tab-active':'';?>">Users</a>
	<a href="admin.php?page=paid-membership&tab=content" class="nav-tab <?php echo $active_tab=='content'?'nav-tab-active':'';?>">Content</a>

</h2>

<form method="post" action="<?php echo "admin.php?page=paid-membership&tab=".$active_tab; ?>">
<?php

			switch ($active_tab)
			{
			case 'settings':
				$options['loginMessage'] = htmlspecialchars(stripslashes($options['loginMessage']));
?>
<h3>General Settings</h3>
Configure general settings.

<h4>Login Message</h4>
<textarea name="loginMessage" id="loginMessage" cols="100" rows="3"><?php echo $options['loginMessage']?></textarea>
<br>Message for site visitors when trying to access membership upgrade without login.

<h4>Free Role</h4>
<input name="freeRole" type="text" id="freeRole" size="16" maxlength="64" value="<?php echo $options['freeRole']?>"/>
<BR>Role when membership expires. Ex: Subscriber

<h4>Membership Listings CSS</h4>
<?php
				$options['customCSS'] = htmlentities(stripslashes($options['customCSS']));

?>
<textarea name="customCSS" id="customCSS" cols="100" rows="8"><?php echo $options['customCSS']?></textarea>

<?php
				break;

			case 'membership':


				$memberships = $options['memberships'];

				if ($_POST['importMemberships'])
				{
					echo 'Importing Memberships... Save if everything shows fine.';
					$memberships = unserialize(stripslashes($_POST['importMemberships']));
				}
				if ($_POST['label_new'])
				{
					$i = count($memberships);


					foreach (array('label','role','price', 'expire','recurring') as $varName)
					{
						if (isset($_POST[$varName .  '_new'])) $memberships[$i][$varName] = $_POST[$varName .  '_new'];
					}


				}

				if ($_GET['add'])
				{
					$i = '_new';

?>

					 <h3>Add New Membership </h3>
<?php

?>
					 Label <input name="label<?php echo $i ?>" type="text" id="label<?php echo $i ?>" size="16" maxlength="64" value="Membership"/>
					 <BR>Role <input name="role<?php echo $i ?>" type="text" id="role<?php echo $i ?>" size="16" maxlength="64" value="Author"/>
					 <BR>Price <input name="price<?php echo $i ?>" type="text" id="price<?php echo $i ?>" size="4" maxlength="10" value="5"/>
					 <BR>Expire <input name="expire<?php echo $i ?>" type="text" id="expire<?php echo $i ?>" size="4" maxlength="10" value="30"/> days
					 <BR>Recurring <select name="recurring<?php echo $i ?>" id="recurring<?php echo $i ?>">
					  <option value="1" selected>Yes</option>
					  <option value="0" >No</option>
					</select>

<?php
				}
				else
				{
?>
<br><a class="button" href="admin.php?page=paid-membership&tab=membership&add=1">Add New Membership</a>

					 <h3>Current Memberships</h3>
<?php

					if (!is_array($memberships))
					{
						echo 'No memberships defined!';
						$memberships = array();
					}
					else
						foreach ($memberships as $i => $membership)
							if (isset($_POST['delete' . $i])) unset($memberships[$i]);
							else
							{

								foreach (array('label','role','price', 'expire','recurring') as $varName)
								{
									if (isset($_POST[$varName . $i])) $memberships[$i][$varName] = $_POST[$varName . $i];
								}

?>
					 <h4>Membership # <?php echo ($i + 1)?> </h4>
					 Label <input name="label<?php echo $i ?>" type="text" id="label<?php echo $i ?>" size="16" maxlength="64" value="<?php echo $memberships[$i]['label']?>"/>
					 <BR>Role <input name="role<?php echo $i ?>" type="text" id="role<?php echo $i ?>" size="16" maxlength="64" value="<?php echo $memberships[$i]['role']?>"/>
					 <BR>Price <input name="price<?php echo $i ?>" type="text" id="price<?php echo $i ?>" size="4" maxlength="10" value="<?php echo $memberships[$i]['price']?>"/>
					 <BR>Expire <input name="expire<?php echo $i ?>" type="text" id="expire<?php echo $i ?>" size="4" maxlength="10" value="<?php echo $memberships[$i]['expire']?>"/> days
					 <BR>Recurring <select name="recurring<?php echo $i ?>" id="recurring<?php echo $i ?>">
  <option value="1" <?php echo $memberships[$i]['recurring']=='1'?"selected":""?>>Yes</option>
  <option value="0" <?php echo $memberships[$i]['recurring']=='0'?"selected":""?>>No</option>
</select>
					<BR>Delete <input name="delete<?php echo $i ?>" type="checkbox" id="delete<?php echo $i ?>" />
					 <?php
							}


						$options['memberships'] = $memberships;
					update_option('VWpaidMembershipOptions', $options);
				}

?>

				<p>
				Recurring: Auto renew membership when it expires (if credits are available).
				<br>Label: Label to show to users.
				</p>

				<H4>Current Memberships Data (Export)</H4>
				<textarea readonly cols="120" rows="3"><?php echo htmlspecialchars(serialize($memberships))?></textarea>

				<H4>Default Memberships Data</H4>
				<textarea readonly cols="120" rows="3"><?php echo htmlspecialchars($optionsDefault['memberships'])?></textarea>

				<H4>Import Memberships Data</H4>
				<textarea cols="120" name="importMemberships" id="importMemberships" rows="4"></textarea>
				<br>If everything shows fine after import, Save Changes to apply.

				<?php
				break;

			case 'billing':
?>
<h3>Billing Settings</h3>
<a target="_read" href="http://paidvideochat.com/features/quick-setup-tutorial/">Read about setting up billing plugins ...</a>

<h4>1) myCRED</h4>
<?php
				if (is_plugin_active('mycred/mycred.php')) echo 'Detected'; else echo 'Not detected. Please install and activate <a target="_mycred" href="https://wordpress.org/plugins/mycred/">myCRED</a> from <a href="plugin-install.php">Plugins > Add New</a>!';

				if (function_exists( 'mycred_get_users_cred'))
				{
					echo '<br>Testing balance: You have ' . mycred_get_users_cred() . ' credits (tokens).';
?>
	<ul>
		<li>* <a href="admin.php?page=mycred">Transactions Log</a></li>
		<li>* <a href="users.php">User Credits History & Adjust</a></li>
	</ul>
					<?php
				}
?>

<p><a target="_mycred" href="https://wordpress.org/plugins/mycred/">myCRED</a> is an adaptive points management system that lets you award / charge your users for interacting with your WordPress powered website. The Buy Content add-on allows you to sell any publicly available post types, including posts managed by this plugin. You can select to either charge users to view the content or pay the post's author either the whole sum or a percentage.<p>



<h4>2) myCRED buyCRED Module</h4>
 <?php
				if (class_exists( 'myCRED_buyCRED_Module' ) )
				{
					echo 'Detected';
?>
	<ul>
		<li>* <a href="edit.php?post_type=buycred_payment">Pending Payments</a></li>
		<li>* <a href="admin.php?page=mycred-purchases-mycred_default">Purchase Log</a> - If you enable BuyCred separate log for purchases.</li>
		<li>* <a href="edit-comments.php">Troubleshooting Logs</a> - MyCred logs troubleshooting information as comments.</li>
	</ul>
					<?php
				} else echo 'Not detected. Please install and activate myCRED with <a href="admin.php?page=mycred-addons">buyCRED addon</a>!';
?>
<p>
myCRED <a href="admin.php?page=mycred-addons">buyCRED addon</a> should be enabled and at least 1 <a href="admin.php?page=mycred-gateways">payment gateway</a> configured for users to be able to buy credits.
<br>Setup a page for users to buy credits with shortcode <a target="mycred" href="http://codex.mycred.me/shortcodes/mycred_buy_form/">[mycred_buy_form]</a>.
<br>Also "Thank You Page" should be set to "Webcams" and "Cancellation Page" to "Buy Credits" from <a href="admin.php?page=mycred-settings">buyCred settings</a>.</p>
<p>Troubleshooting: If you experience issues with IPN tests, check recent access logs (recent Visitors from CPanel) to identify exact requests from billing site, right after doing a test.</p>
<h4>3) myCRED Sell Content Module</h4>
 <?php
				if (class_exists( 'myCRED_Sell_Content_Module' ) ) echo 'Detected'; else echo 'Not detected. Please install and activate myCRED with <a href="admin.php?page=mycred-addons">Sell Content addon</a>!';
?>
<p>
myCRED <a href="admin.php?page=mycred-addons">Sell Content addon</a> should be enabled as it's required to enable certain stat shortcodes. Select Post Types you want to sell in <a href="admin.php?page=mycred-settings">Sell Content settings tab</a> so access to webcams can be sold from backend. You can also configure payout to content author from there (Profit Share) and expiration, if necessary.
<?php

				$hideSubmit=1;

				break;

			case 'users':
?>
<h3>Users</h3>
Users with membership.
<br>
<?php

				VWpaidMembership::membership_update_all();

				$users = get_users(
					array(
						'meta_key'     => 'vw_paid_membership',
						'fields' => 'ID'
					));

				if (count($users))
					foreach ( $users as $user )
					{
						$user_info = get_userdata($user);
						echo '<br>' . $user_info->user_login . ' : ' ;
						echo VWpaidMembership::membership_info($user);
					}
				else echo "Currently, no users have paid membership setup with this plugin.";

				$hideSubmit=1;

				break;


			case 'content':
?>
<h3>Paid Content</h3>
Content (posts) that require purchase for access.

<h4>Paid Content Handling</h4>
<select name="paid_handler" id="paid_handler">
  <option value="videowhisper" <?php echo $options['paid_handler']=='videowhisper'?"selected":""?>>VideoWhisper</option>
  <option value="mycred" <?php echo $options['paid_handler']=='mycred'?"selected":""?>>MyCred</option>
</select>
<br>VideoWhisper Paid Membership and Content supports custom pricing for some plugins (special discounts).
<?php
				$posts = get_posts(
					array(
						'meta_key'         => 'myCRED_sell_content',
						'post_type' => 'any',
						'post_status' => 'any',
						//      'post_type'     => array ( 'post', 'page', 'presentation', 'channel', 'webcam', 'video'),
						'orderby'          => 'date',
						'order'            => 'DESC',
						'suppress_filters' => true
					));

				foreach ($posts as $post)
				{
					$meta = get_post_meta($post->ID, 'myCRED_sell_content', true);
					echo '<p>';
					echo '<a href="' . get_post_permalink($post->ID).'">' . $post->post_name . '</a> ';
					echo ' Price: ' . $meta['price'] . ', Duration: '. ($meta['expire']?($meta['expire'].' h'):'unlimited') . ', ' . ($meta['recurring']?'recurring.':'one time fee.');
					echo '</p>';
				}

				$hideSubmit=1;

				break;
			}

			if (!$hideSubmit) submit_button();
			echo '</form>';

		}


	}
}


//instantiate
if (class_exists("VWpaidMembership"))
{
	$paidMembership = new VWpaidMembership();
}

//Actions and Filters
if (isset($paidMembership))
{
	register_activation_hook( __FILE__, array(&$paidMembership, 'activation' ) );
	register_deactivation_hook( __FILE__, array(&$paidMembership, 'deactivation' ) );

	add_action('init', array(&$paidMembership, 'init'));
	add_action("plugins_loaded", array(&$paidMembership, 'plugins_loaded'));

	add_action('cron_membership_update', array(&$paidMembership, 'membership_update_all'));

	//admin
	add_action('admin_menu', array(&$paidMembership, 'admin_menu'));
}



?>
