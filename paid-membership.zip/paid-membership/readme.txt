=== Paid Membership and Content ===
Contributors: videowhisper, VideoWhisper.com
Author: VideoWhisper.com
Author URI: http://www.videowhisper.com
Plugin Name: Paid Membership and Content
Plugin URI: http://www.videochat-scripts.com/paid-membership-plugin/
Donate link: http://www.videowhisper.com/?p=Invest
Tags: paid membership, MyCred, tokens, subscription, paypal, zombaio, bitcoin, sell post, VideoWhisper
Requires at least: 2.7
Tested up to: 4.7
Stable tag: trunk

Setup paid membership (roles) and content selling using tokens (purchased with real money or earned for site activity).

== Description ==

= Key Features =
* Sell Membership: Users can obtain roles (membership) by purchase or subscription.
* Sell Content: Provides an edit content page in frontend for users to be able to sell individual post items (integrates automatically with VideoShareVOD plugin videos, Picture Gallery plugin pictures).
* Wallet (Tokens/Credits) Based: This plugin uses tokens from the myCred plugin as currency.
These tokens can be purchased using multiple payment gateways like Paypal, Skrill (Moneybookers) NETbilling, Zombaio, BitPay (bitcoin)  or earned with site activities, depending on setup.

= Recommended for use with these solutions =
* [Paid VideoChat](http://paidvideochat.com/ "Paid VideoChat Script")
* [Video Share VOD](http://wordpress.org/plugins/video-share-vod/  "Video Share / Video On Demand Script")
* [Broadcast Live Video](http://broadcastlivevideo.com/ "Broadcast Live Video Camera Script")

= Benefits of using tokens include: =
* less transaction fees (clients fund their account once for multiple purchases)
* cost control (clients can have added peace of mind and sensation of control for the fixed amount they pay),
* payment in advance (clients prepay for future services) ,
* increased sales (once the have the tokens they will put them to use faster than real money)


== Installation ==
* Install and activate plugin
* Setup membership packages from Paid Membership - Settings - Membership Levels
* Go to Paid Membership - Settings - Billing section and make sure mycred is installed, active and configured
* Use [videowhisper_membership_buy] shortcode to list packages in frontend to users


== Screenshots ==
1. Users can purchase membership with credits.


== Documentation ==
http://www.videochat-scripts.com/paid-membership-plugin/


== Demo ==
* See WordPress integration (after login):
http://www.videochat-scripts.com/buy-membership/


== Extra ==
More information, the latest updates, other plugins and non-WordPress editions can be found at http://www.videowhisper.com/ .


== Changelog ==

= 1.3 =
* Edit content on a custom page /edit-content/?editID=[post id]
* Set paid content with mycred plugin
* Automatically detected and integrated for VideoShareVOD videos
* Only owner and administrator can edit

= 1.2 =
* Improvements

= 1.1 =
* Original release