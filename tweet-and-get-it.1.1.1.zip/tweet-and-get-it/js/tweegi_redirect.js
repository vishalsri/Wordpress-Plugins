function tweegiopenNewWindow(url) {
 popupWin = window.open(url,
 'open_window',
 'menubar, toolbar, location, directories, status, scrollbars, resizable, dependent, width=940, height=580, left=350, top=300');
 }
