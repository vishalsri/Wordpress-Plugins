=== Tweet And Get it ! ===
Plugin URI: http://tweetandgetit.com/
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=345MJU6MYCHPJ
Author: Via Internet UK Ltd.
Author URI: http://tweetandgetit.com/
Tags: tweet and get it,twitter followers, marketing viral tools,twitter widget, twitter sidebar, twitter tools, monetize blog, more twitter followers free,get twitter followers,free ebooks, pdf download, music download
Requires at least: 2.8
Tested up to: 3.2.1
Stable tag: 1.1.1
Contributors: tweetandgetit	 

Tweet&Get it ! is an automatic process to get Twitter followers in exchange for a downloadable file. 

== Description ==
Tweet&Get it ! is an automatic process to get Twitter followers in exchange for a downloadable file. Get your shortcodes by setting up your Tweet&Get it ! buttons. Copy/paste the shortcodes into posts, pages and widgets areas. Your Tweet&Get it ! buttons will immediately be available to your visitors.

Tweet&Get it ! is seriously recommended to share content such as: Music, Ebooks, Photos, Wallpapers, Promotional Codes, Coupons, Typography, CMS Themes, Videos, Software, Tutorials, Web Resources, Icons, PSD Brushes ...

Get a new follower with each download !!

*Now includes .po files for translations (submit yours @ http://tweetandgetit.com/translation)*


**Features**

    * Create as many buttons as you need, there is no limit
    * Set up a Tweet for each button you create
    * Upload all the files you want (check your Wordpress settings for limitations >> max upload file size)
    * Get a shortcode for each button.
    * The shortcodes can be used in Posts / Pages / Widgets / Excerpts ...
    * Full Dashboard to manage your buttons:

    - Edit your buttons (change your files, Tweets and Twitter Accounts)
    - Delete your buttons
    - Overview of all your shortcodes

    * Easily translate the plugin into your language
    * Tweet&Get it ! is already available in English, French, German and Japanese.
	
Tags: tweet and get it,twitter followers, marketing viral tools,twitter widget, twitter sidebar, twitter tools, monetize blog, more twitter followers free,get twitter followers,free ebooks, pdf download, music download
	
**Videos**
* Get it started with Tweet&Get it !
[youtube http://youtu.be/SdsCHhj5grM ]

* more videos on our Youtube Channel *
* <a href="http://youtube.com/tweetandgetit/" target="_blank">http://youtube.com/tweetandgetit </a>


**Important Links**

* <a href="http://tweetandgetit.com/demos/" target="_blank">Demos</a>
* <a href="http://getsatisfaction.com/tweetandgetit/" target="_blank">Free Support</a>
* <a href="http://tweetandgetit.com/" target="_blank">Official Website</a>


**Requirements**
 * Wordpress 2.5 or higher. The plugin is also ready for Wordpress 3.2+ :)
 * PHP 5+
 * SAFE mode on your server system has to be turned off
 
** Press reviews **

* <a href="http://www.wpbeginner.com/plugins/get-twitter-followers-in-exchange-of-downloadable-files-in-wordpress/" target="_blank"> WP Beginner, Get Twitter followers in exchange of downloadable files </a>
* <a href="http://www.wpexplorer.com/blog/tweet-get-it-plugin.html/" target="_blank"> WP Explorer, Tweet&Get it ! Plugin </a>
* <a href="http://maketecheasier.com/tweet-and-get-it-increase-twitter-followers/2011/07/13" target="_blank"> Make Tech Easier,Increase Twitter followers </a>
*<a href="http://wpcanada.ca/2011/plugin-review-tweet-and-get-it/" target="_blank"> WP Canada, Tweet&Get it review </a>
* <a href="http://www.wpmods.com/tweet-and-get-it-wordpress-plugin" target="_blank">WP Mods, interview of the Tweet&Get it ! team </a>
* <a href="http://www.bloggz.net/2011/04/14/get-new-tweet-get-it-wordpress-plugin/" target="_blank">Bloggz -> Get new Tweet&Get it! Wordpress Plugin</a>
* <a href="http://wpchannel.com/tweet-get-it-plugin-twitter-booster-nombre-followers-wordpress/" target="_blank">WP Channel -> Un plugin pour booster votre nombre de followers</a>
* <a href="http://bivori.com/replace-download-button-tweet-and-get-it/" target="_blank">Bivori -> Replace download button with Tweet&get it !</a>
* <a href="http://infopioneer.co.cc/2011/04/14/get-new-tweet-get-it-wordpress-plugin/" target="_blank">Infopionner -> Get new Tweet&Get it! Wordpress Plugin</a>
* <a href="http://www.dotpod.com.ar/2011/04/28/tweet-get-un-plugin-de-wordpress-para-monetizar-los-recursos-gratis-de-tu-blog/" target="_blank">Dotpod -> Tweet&Get it! un plugin de Wordpress para monetizar los recursos gratis de tu blog</a>
*<a href="http://tictacnews.wordpress.com/2011/05/30/tweet-get-it-compartilhe-arquivos-pelo-twitter-e-ganhe-seguidores-por-download/"
target="_blank">Tic Tac News -> Tweet&Get it! Compartilhe arquivos pelo Twitter e ganhe seguidores por download!</a>


== Changelog ==

= Version 1.1.1 =
New language available: Japanese

= Version 1.1 =

* Updated: WordPress 3.2 compatibility changes
* Fixed: Issues with special chars
* Fixed: Issues with tweet-and-get-it-fr_FR.mo
* Fixed: Issues with tweet-and-get-it-de_DE.mo

= Version 1.0 =

First public release

= Version 0.0 =

Development version

== Upgrade Notice ==
= 1.1 =

WordPress 3.2 compatibility changes.

= 1.0 =
First public release

= 0.0 =
Development version

== Installation ==
1. Download and unpack the `download-package`.
2. Upload the tweet-and-get-it folder to the `/wp-content/plugins/` directory
3. Activate the plugin in the `Plugins` section in WordPress
4. Configure the options under Admin Panel `Tweet&Get it ! => Make your button`
5. Enter the Twitter account you want the user to follow in exchange for the download of your file
6. Write the tweet you want the user to send when downloading your file
7. Upload your file or copy/paste its URL
8. Click on `Create your button!` and copy/paste the shortcode wherever you want: posts, pages, widgets, excerpts
9. Then manage your buttons : => Edit your buttons, Delete your buttons, See the shortcodes of each button
10. You are good to go :)
11. Don't hesitate to check out the FAQ for usage

== Frequently Asked Questions ==

Tweet&Get it ! is an automatic process to get Twitter followers in exchange for a downloadable file.

The best place to get your questions answered is through our “Get Satisfaction” dashboard. Our team will be glad to answer your questions, solve your problems and listen to your suggestions. And who knows, maybe someone has already asked your question. 
<a href="http://getsatisfaction.com/tweetandgetit/" target="_blank">Free Support</a>

= Which file types can I share via my Tweet&Get it ! buttons? =

It is fully recommended to share content such as: Music, Documents, Promotional Codes, Coupons, Ebooks, Photos, Wallpapers, Typography, CMS Themes, Videos, Software, Tutorials, Web Resources, Icons, PSD brushes … There is no restriction regarding file types. The maximum weight of the file is set in your server configuration (max_upload_size in your php.ini file). Contact your server admin if you want to increase your maximum upload size. 

= Is Tweet&Get it ! entirely free? =

Yes, Tweet&Get it ! is a 100% free service.

= How many Tweet&Get it ! buttons can I create? =

You can create as many as you want.

= Is it possible to use a different Twitter account for each button? =

Yes of course !

= Is it possible to set up a different promotional tweet for each button? =

Yes of course!  

= Is it possible to provide a file via an URL that is external to my WordPress site? =

It is indeed possible. You can upload a file from your hard drive or just give the URL of your file location. 

= I can't upload my file, what might the problem be? =

Check if Safe Mode is OFF in your server configuration. If you can't turn it off or don't want to mess with it, you can create a tweetandgetit folder manually in your WordPress Uploads. http://myblog/wp-content/uploads/tweetandgetit The folder must be created with 777 chmod permission. Now you should be able to create your Tweet&Get it ! buttons!

= Safe mode is OFF but I still can't upload my files? What can I do? =

Check if there is a folder called Uploads in your WordPress blog. http://myblog/wp-content/uploads/  If not you have to give the wp-content folder 777 chmod permission so that Tweet&Get it ! can create the Uploads folder it needs.

== Screenshots ==
1. Make your Tweet&Get it buttons
2. Manage your buttons
3. Example of a Tweet&Get it button in a blog post
4. Send this tweet and follow this account to access the download ! 
5. Final Step, now you can download your file!