=== Video Posts Webcam Recorder ===
Contributors: videowhisper, VideoWhisper.com
Author: VideoWhisper.com
Author URI: http://www.videowhisper.com
Plugin Name: VideoWhisper Video Posts Webcam Recorder
Plugin URI: http://www.videowhisper.com/?p=WordPress+Video+Recorder
Donate link: http://www.videowhisper.com/?p=Invest
Tags: video, flash, wowza, plugin, media, av, clip, recorder, recording, webcam, cam, post, posts, WYSIWYG, editor, share, insert, camera, VideoShareVOD, VideoWhisper, shortcode, reaction
Requires at least: 2.7
Tested up to: 4.9
Stable tag: trunk

The Video Posts Webcam Recorder allows the WordPress administrators and authors to record and insert videos in their posts.

== Description ==
The Video Posts Webcam Recorder allows the WordPress administrators and authors to record and insert videos in their posts by adding an insert recording button to WYSIWYG editor.

Integrates with the [Video Share VOD](http://wordpress.org/plugins/video-share-vod/  "Video Share / Video On Demand") WordPress plugin for advanced video management, multiple customisable conversions, multiple players, delivery methods and settings (recommended).
Can also be used to sell videos, in combination with [Paid Membership and Content](https://wordpress.org/plugins/paid-membership/  "Paid Membership and Content Subscriptions by Tokens/Credits").
Stand alone VSV videos can be recorded with [videowhisper_recorder category="category-name"] shortcode.

Recording can be done with the insert tool when editing posts or with the "videowhisper_recorder" shortcode that displays the interface to record video (uses permissions from VideoShareVOD if enabled).

= Recording During Video Playback =
Supports Youtube / Vimeo video synchronised reaction recordings (start recording at same time with a video and record during playback, great for karaoke or standard interviews / questionnaires and live reactions):   
[videowhisper_recorder youtube_sync="video-id" category="category-name"]
[videowhisper_recorder vimeo_sync="video-id" category="category-name"]


= Special Requirements =
This plugin has requirements beyond regular WordPress hosting specifications: a RTMP host is needed for persistent connections to manage live interactions and streaming (Wowza recommended). More details about this, including solutions are provided on the Installation section pages.

= Home Page =
Find more details about the Video Recorder application and WordPress integrations on [Video Recorder Posts Comments](http://www.videowhisper.com/?p=WordPress+Video+Recorder+Posts+Comments  "Video Recorder Posts Comments") home page.

== Installation ==
* See latest version instructions on plugin homepage: http://www.videowhisper.com/?p=WordPress+Video+Recorder+Posts+Comments
* Before installing this make sure all hosting requirements are met: http://www.videowhisper.com/?p=Requirements
* Install the RTMP application using these instructions: http://www.videowhisper.com/?p=RTMP+Applications
* Copy this plugin folder to your wordpress installation in your plugins folder or install it automatically from repository from your backend.
* Enable the plugin from Wordpress admin area and fill the "Settings", including rtmp address there.

== Screenshots ==
1. Record Button (when writing a post)
2. Recorder Application

== Desktop Sharing / Screen Broadcasting ==
If your users want to broadcast their screen (when playing a game, using a program, tutoring various computer skills) they can do that easily just by using a screen sharing driver that simulates a webcam from desktop contents. Read more on http://www.videochat-scripts.com/screen-sharing-with-flash-video-chat-software/ .

== Documentation ==
* Plugin Homepage : http://www.videowhisper.com/?p=WordPress+Video+Recorder+Posts+Comments
* Application Homepage : http://www.videowhisper.com/?p=Video+Recorder
* Support Page: http://www.videowhisper.com/tickets_submit.php

== Demo ==
See a video posted with this plugin on: http://www.videochat-scripts.com/webcam-video-recorder-for-wordpress/

== Extra ==
More information, the latest updates, other plugins and non-WordPress editions can be found at http://www.videowhisper.com/ .

== Changelog ==

= 2.6 =
* Vimeo player synchronised recordings with [videowhisper_recorder vimeo_sync="video-id"]

= 2.4 =
* Recorder app has ability to pause, resume - useful for sync with playback of another video

= 1.98 =
* VideoWhisper Video Recorder 1.98
* Youtube player synchronised recordings with [videowhisper_recorder youtube_sync="video-id"]

= 1.92 =
* VideoWhisper Video Recorder 1.92
* Video Container configuration

= 1.85.1 =
* VideoShareVOD integration for advanced video management and playback
* [videowhisper_recorder] Shortcoder

= 1.55 =
* Integrates VideoWhisper Video Recorder 1.55
* HTML5 playback support (if conversion is possible)
* Import previous recording in posts

= 1.45.4 =
* Support stream names with spaces fix

= 1.45.3 =
* Folder location fix (from videoposts to

= 1.45.2 =
* Shortcodes for code reliability
* Support for JwPlayer Plugin http://wordpress.org/extend/plugins/jw-player-plugin-for-wordpress/
* More settings

= 1.45 =
* First release
* Integrates VideoWhisper Video Recorder 1.45
* Record and embed video when writing post
* Settings
* Recordings list to delete recording files (if folder is accessible)