<?php

$rtmp_server="rtmp://localhost/videowhisper-recorder";
// rtmp://your-server-ip-or-domain/application

$rtmp_amf="AMF3";
// AMF3 : Red5, Wowza, FMIS3, FMIS3.5
// AMF0 : FCS1.5, FMS2
// blank for flash default

$jwplayer=0;
// 1 : enable jwplayer installed in jwplayer folder

$delete_from="";
// enable delete recording from specified folder (ending in /)
?>