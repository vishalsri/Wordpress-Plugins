# Lively Tutorial

This repo is intended to provide a demo and a tutorial of LivelyVideo core functionality.  Each demo can be found in sub folders.  This is currently a work in progress, just ask us any questions and we will try to respond as quickly as possible.
