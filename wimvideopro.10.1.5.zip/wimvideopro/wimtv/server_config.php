<?php
$server_host = "https://new.wim.tv";