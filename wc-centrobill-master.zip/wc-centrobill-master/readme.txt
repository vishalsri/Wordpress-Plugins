==== CentroBill Payment Gateway Addon ====
Plugin Name: Centrobill WooCommerce Addon
Plugin URI: https://wordpress.org/plugins/wc_centrobill/
Tags: woocommerce plugin centrobill
Requires at least: WP 4.0  & WooCommerce 2.2+
Tested up to: 4.8 & WooCommerce 3.1.1
Stable tag: 1.0.3
Version: 1.0.3
License: http://www.gnu.org/licenses/gpl-3.0.html