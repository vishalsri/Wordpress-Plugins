<?php
global $wp_user_appearance_button_type;
do_action('wpuser_appearance_skin');