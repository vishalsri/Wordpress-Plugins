=== Frontend Dashboard Extra===
Contributors: vinoth06, buffercode
Tags: dashboard, frontend dashboard extra, date, file upload, image upload, calendar, date and time, color
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=7DHAEMST475BY
Requires at least: 4.6
Tested up to: 4.9.1
Stable tag: 1.3.1
License: GPL V3
License URI: https://www.gnu.org/licenses/gpl-3.0.en.html

Frontend Dashboard Extra WordPress plugin is a supportive plugin for Frontend Dashboard with supportive additional features likes extra Calendar for selecting date and time, Colors and File Upload for images.

== Description ==

> #### Notice
> This is a Add-on plugin of [Frontend Dashboard](https://wordpress.org/plugins/frontend-dashboard/), So please install [Frontend Dashboard](https://buffercode.com/plugin/frontend-dashboard) to use this plugin

Frontend Dashboard Extra WordPress plugin is a supportive plugin for Frontend Dashboard with supportive additional features likes extra Calendar for selecting date and time, Colors and File Upload for images.

= Date and Time Calendar =

Shows Date and Time Calendar with high customizations like changing the date format, selecting date range and multiple selection and time with 12 and 24 hours

= Colors =

Choosing color by variety of hexadecimal codes

= File Upload =

Image files can be uploaded for the registered users in the Frontend Dashboard.

== Installation ==
1. Upload the “frontend-dashboard-extra” directory to the plugins directory.
2. Go to the plugins setting page and activate “Frontend Dashboard Extra”
3. Go to Frontend Dashboard and add the Date, Color and File input fields
4. Do save.

== Changelog ==

= v1.3.1 [24-January-2018] =
* Bug fixes

= v1.3 [20-December-2017] =
* Bug: Uploading documents causing preview not found

= v1.2.1 [14-December-2017] =
* Not able to add the field due to nonce field

= v1.2 [06-December-2017] =
* Bug fixes

= v1.1 [25-November-2017] =
* Bug fixed

= v1.0 [19-October-2017] =
* Public release

== Upgrade Notice ==
= v1.2.1 [14-December-2017] =
* Not able to add the field due to nonce field

== Screenshots ==
1. Date and Time
2. Color
3. File